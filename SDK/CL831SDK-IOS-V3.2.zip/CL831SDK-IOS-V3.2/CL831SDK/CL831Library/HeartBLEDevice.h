//
//  HeartBLEDevice.h
//  HeartTestDemo
//
//  Created by 郭志奇 on 2019/8/7.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@class HeartBLEDevice;

@protocol BLEDeviceDelegate <NSObject>

//Get device information
- (void)SDKgetInfo:(NSData *)info withDevice:(HeartBLEDevice *)Device;

- (void)SDKFitRunSParamter:(int)RunPara andFitKM:(float)FitKM andFitCalor:(float)FitCalor;

- (void)SDKFitHeartParamter:(NSString *_Nonnull)HeartStr;

- (void)SDKDianciStr:(NSString *_Nullable)DianStr;

- (void)SDKReadRSSI:(NSString *_Nullable)RSSIStr;

- (void)SDKDeviceBanBen:(NSString *_Nullable)BenStr;

- (void)SDKRealData:(NSData *_Nullable)data;

- (void)SDKGet7DaysHisParam:(NSMutableArray *_Nullable)ParamArr;

- (void)SDKGetHisHRUTCArr:(NSMutableArray *_Nullable)UTCArr;

- (void)SDKGetHisHRParaArr:(NSMutableArray *_Nullable)UTCArr andHisHRArr:(NSMutableArray *_Nullable)HRArr;

- (void)SDKGetIntertTimeArr:(NSMutableArray *_Nullable)ParaArr;

- (void)SDKGetSingleUTCArr:(NSMutableArray *_Nullable)UTCArr;

- (void)SDKGetUserInfoState:(NSString *_Nullable)StateStr;

- (void)SDKUserInfo:(NSString *_Nullable)OLdStr andSex:(NSString *_Nullable)SexStr andWeight:(NSString *_Nullable)WeightStr andHeight:(NSString *_Nullable)HeightStr andPhoneNum:(NSString *_Nullable)PhNumStr;

- (void)SDKBagCountStr:(NSString *_Nullable)CountStr;
- (void)SDKBag1CountStr:(NSString *_Nullable)CountStr;

//unit: minute
- (void)SDKGetTimeOffWrist:(int)time isSet:(BOOL)isSet;

/// getUTCAndHeartAlertSwitch callback
/// @param utc current utc
/// @param alertType  0: alert by age, 1: alert by Hi-Losetting
- (void)SDKGetUTC:(long)utc type:(int)alertType;

/// APP reading interval heart rate alert switch and the maximum value
- (void)SDKGetHRGoal:(int)goal max:(int)max min:(int)min;


/// Get 3D raw data
/// @param rawData  raw data list 
- (void)SDKGet3DData:(NSArray *)rawData;

- (void)SDKGetMaxHeartRate:(int)heartRate;

/// 获取睡眠数据的回掉
/// @param sleepData 睡眠数据 动作指数说明：  > 20 没睡， < 20 浅睡  3个连续0为深睡 需要根据数据来统计浅睡，深睡，清醒等时间段
- (void)SDKGetSleepData:(NSArray *)sleepData;

/// get 3d data frequency
- (void)SDKGet3DFrequency:(int)frequency;

/// 3D data stutus
/// @param isOpen  YES: open, NO: close
- (void)SDKGet3DDataState:(BOOL)isOpen;

/// ---
/// 健康数据的回调
/// @param Vo2Max 最大摄氧量
/// @param breathRate 呼吸频率
/// @param emotionLevel 心情等级
/// @param stressPercent 压力百分率
/// @param stamina 疲劳等级
- (void)SDKGetVo2Max:(int)Vo2Max breathRate:(int)breathRate emotionLevel:(int)emotionLevel stressPercent:(int)stressPercent stamina:(int)stamina;

/// 获取实时温度数据
/// @param ambient 环境温度
/// @param wrist 手腕温度
/// @param body 体温
- (void)SDKGetRealTimeTemp:(float)ambient wrist:(float)wrist body:(float)body;


/// 获取血氧值
/// @param BloodOxygen 血氧值
/// @param posture 手腕姿势是否正确，YES 正确，NO 错误
/// @param PI 红光PI值  0：未检测到脉搏，<8信号较弱，>15信号良好
/// @param onWrist 是否脱腕
- (void)SDKGetBloodOxygen:(int)BloodOxygen wristPosture:(BOOL)posture redPI:(int)PI onWrist:(BOOL)onWrist;

/// 获取计步历史UTC
- (void)SDKGetCalculateStepUTC:(NSMutableArray *_Nullable)UTCArr;
/// 通过获取计步历史记录列表时间来获取该UTC时间的计步数据
- (void)SDKGetHisStepParaArr:(NSMutableArray *_Nullable)UTCArr andHisStepArr:(NSMutableArray *_Nullable)StepArr;

@end

@interface HeartBLEDevice : NSObject

//connection
- (void)connect;

//disconnect
- (void)disconncet;

//Set the agent
- (void)setDelegate:(id)delegate;

//Data is written to
- (void)BLEReadData:(NSString *)dataStr;

///获取脱腕关机时间
- (void)getTimeOffWrist;
///设置脱腕关机时间 unit: minute
- (void)setTimeOffWrist:(int)time;

///get UTC and age heart rate alert switch
- (void)getUTCAndHeartAlertSwitch;
///set Interval heart rate alert switch
- (void)setHeartAlertSwitch:(BOOL)isOn;

///Obtain heart rate interval and target heart rate
- (void)getHRGoalAndRange;

/// Set heart rate interval and target heart rate
- (void)setHRGoal:(int)goal max:(int)max min:(int)min;

- (void)enterDFU;

- (void)setMaxHeartRate:(int)maxHr;
- (void)getMaxHeartRate;

- (void)getSleepData;

/// get 3d data frequency
- (void)get3DFrequency;

/// set 3d data frequency
- (void)set3DFrequency:(int)frequency;

/// 3D data open or close
/// - Parameter isOpen: open: YES, close: NO
- (void)openOrClose3DData:(BOOL)isOpen;
/// get 3d raw data switch state
- (void)get3DSwithState;


/// 进入血氧模式
- (void)enterOxygenMode;
/// 退出血氧模式
- (void)quitOxygenMode;
/// 请求实时温度
- (void)requestRealTimeTemperature;

- (void)requestStepUTC;


// Device name
@property (nonatomic,copy) NSString *DeviceName;

//UUID
@property (nonatomic,copy) NSString *UUIDStr;

//Equipment signal strength
@property (nonatomic,copy) NSString *RSSI;

//Initialization service
- (instancetype)initWithPeriphral:(id)thePeripheal;

@end

NS_ASSUME_NONNULL_END
