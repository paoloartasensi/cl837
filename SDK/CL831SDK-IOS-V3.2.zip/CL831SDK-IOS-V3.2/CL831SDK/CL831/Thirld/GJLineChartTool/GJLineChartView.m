//
//  GJLineChartView.m
//  GJLineChartView
//
//  Created by gaojun on 2017/9/31.
//  Copyright © 2017年 GJ. All rights reserved.
//

#import "GJLineChartView.h"
#import "XAxisView.h"
#import "YAxisView.h"

#define leftMargin 25
#define lastSpace 50

@interface GJLineChartView ()<UIScrollViewDelegate>
{
    int ScrIndex;
    int TotalLength;
    int Everyleng;
}

@property (strong, nonatomic) NSArray *xTitleArray;
@property (strong, nonatomic) NSArray *yValueArray;
@property (assign, nonatomic) CGFloat yMax;
@property (assign, nonatomic) CGFloat yMin;
@property (strong, nonatomic) YAxisView *yAxisView;
@property (strong, nonatomic) XAxisView *xAxisView;
@property (strong, nonatomic) UIScrollView *scrollView;
@property (assign, nonatomic) CGFloat pointGap;
@property (assign, nonatomic) CGFloat defaultSpace;//间距
@property (strong, nonatomic) NSString *unit;
@property (assign, nonatomic) CGFloat moveDistance;



@end

@implementation GJLineChartView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self){
        self.backgroundColor = [UIColor whiteColor];
        
        _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(leftMargin, 0, self.frame.size.width - leftMargin, self.frame.size.height)];
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.bounces = NO;
        _scrollView.scrollEnabled = YES;
      //  _scrollView.delegate = self;
        [self addSubview:_scrollView];

//        self.yAxisView = [[YAxisView alloc]initWithFrame:CGRectMake(0, 0, leftMargin, self.frame.size.height)];
//        self.yAxisView.backgroundColor = [UIColor whiteColor];
//        [self addSubview:self.yAxisView];
        
        self.xAxisView = [[XAxisView alloc]initWithFrame:_scrollView.bounds];
        self.xAxisView.backgroundColor = [UIColor whiteColor];
        [_scrollView addSubview:self.xAxisView];

    }
    return self;
}

- (void)xTitleArray:(NSArray*)xTitleArray
        yValueArray:(NSArray*)yValueArray
               yMax:(CGFloat)yMax
               yMin:(CGFloat)yMin
               unit:(NSString*)unit
{
    self.xTitleArray = xTitleArray;
    self.yValueArray = yValueArray;
    self.yMax = yMax;
    self.yMin = yMin;
    self.unit = unit;
    
    if (xTitleArray.count > 600) {
        _defaultSpace = 5;
    }
    else if (xTitleArray.count > 400 && xTitleArray.count <= 600){
        _defaultSpace = 10;
    }
    else if (xTitleArray.count > 200 && xTitleArray.count <= 400){
        _defaultSpace = 20;
    }
    else if (xTitleArray.count > 100 && xTitleArray.count <= 200){
        _defaultSpace = 30;
    }
    else {
        _defaultSpace = 40;
    }
    
    self.pointGap = _defaultSpace;
    
    [self creatYAxisView];
    [self creatXAxisView];
    
    // 2. 捏合手势
    UIPinchGestureRecognizer *pinch = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchGesture:)];
    [self.xAxisView addGestureRecognizer:pinch];
    
    //长按手势
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(event_longPressAction:)];
    [self.xAxisView addGestureRecognizer:longPress];
}

- (void)creatYAxisView
{
    for (UIView *Views in [self subviews])
    {
        if ([Views isEqual:self.yAxisView])
        {
            [Views removeFromSuperview];
        }
    }
    
    self.yAxisView = [[YAxisView alloc]initWithFrame:CGRectMake(0, 0, leftMargin, self.frame.size.height) yMax:self.yMax yMin:self.yMin unit:self.unit];
    [self addSubview:self.yAxisView];
    //[self.yAxisView yMax:self.yMax yMin:self.yMin unit:self.unit];
}

- (void)creatXAxisView
{
    NSLog(@"self.xTitleArray.count数组个数:%ld",self.xTitleArray.count);
    NSLog(@"屏幕宽度:%f",self.frame.size.width - leftMargin);
    TotalLength = self.xTitleArray.count * self.pointGap;
    NSLog(@"视图列表的总长度:%f",self.xTitleArray.count * self.pointGap + lastSpace);

    Everyleng = (int)(TotalLength / self.xTitleArray.count);

    NSLog(@"每个数的长度:%d",Everyleng);
 
    int countS = (int)(self.scrollView.frame.size.width / Everyleng);

    NSLog(@"个数啦啦啦:%d",countS);

//    NSArray *GEtOnexArr = [self.xTitleArray subarrayWithRange:NSMakeRange(0, countS)];
//    NSArray *GEtOneyArr = [self.yValueArray subarrayWithRange:NSMakeRange(0, countS)];
    
    self.xAxisView.frame = CGRectMake(0, 0, self.xTitleArray.count * self.pointGap + leftMargin, self.scrollView.frame.size.height);
    [self.xAxisView xTitleArray:self.xTitleArray yValueArray:self.yValueArray yMax:self.yMax yMin:self.yMin unit:self.unit];
    _scrollView.contentSize = CGSizeMake(self.xTitleArray.count * self.pointGap + leftMargin, 0);
     
   
    /*
    self.xAxisView = [[XAxisView alloc] initWithFrame:CGRectMake(0, 0, self.xTitleArray.count * self.pointGap+30, self.frame.size.height) xTitleArray:self.xTitleArray yValueArray:self.yValueArray yMax:self.yMax yMin:self.yMin unit:self.unit];
    [_scrollView addSubview:self.xAxisView];
     
    
    _scrollView.contentSize = self.xAxisView.frame.size;
   // _scrollView.contentSize = CGSizeMake(self.xTitleArray.count * self.pointGap, 0);
     */
}

#pragma mark - UIScrollview的代理方法
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //ScrIndex = (scrollView.contentOffset.x + self.scrollView.frame.size.width) - self.scrollView.frame.size.width;
    ScrIndex = scrollView.contentOffset.x;
    
    _scrollView.contentSize = CGSizeMake(self.scrollView.frame.size.width+ScrIndex, 0);
    
    NSLog(@"位置的变化啦啦啦啦:%d",ScrIndex);
}

//滚动视图结束的时候调用
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
{
    NSLog(@"滑动结束的位置:%d",ScrIndex);
    
    if (ScrIndex == 0)
    {
        for (UIView *Views in [_scrollView subviews])
        {
            [Views removeFromSuperview];
        }
        TotalLength = self.xTitleArray.count * self.pointGap + lastSpace;
        
        Everyleng = (int)(TotalLength / self.xTitleArray.count);
        
//        int countS = (int)(ScreenWidth / Everyleng);
        
//        NSArray *GEtOnexArr = [self.xTitleArray subarrayWithRange:NSMakeRange(0, countS)];
//        NSArray *GEtOneyArr = [self.yValueArray subarrayWithRange:NSMakeRange(0, countS)];
    
        
       // self.xAxisView = [[XAxisView alloc] initWithFrame:CGRectMake(0, 0, self.xTitleArray.count * self.pointGap + lastSpace, self.frame.size.height) xTitleArray:GEtOnexArr yValueArray:GEtOneyArr yMax:self.yMax yMin:self.yMin unit:self.unit];
        
        [_scrollView addSubview:self.xAxisView];
        
      //  _scrollView.contentSize = self.xAxisView.frame.size;
        
    }
    
    if (ScrIndex > self.scrollView.frame.size.width)
    {
        int a = (ScrIndex) % (int)(ScreenWidth);

        int count = (ScrIndex) / (int)(ScreenWidth);
        
        if (a != 0)
        {
            count++;
        }

        Everyleng = (int)(TotalLength / self.xTitleArray.count);
        
        NSLog(@"每个数的长度:%d",Everyleng);
        
        int countS = (int)(ScreenWidth / Everyleng);
        
        NSLog(@"个数啦啦啦:%d",countS);
        
        if (ScrIndex > Everyleng)
        {
            int b = (ScrIndex)%(Everyleng);
            
            int count1 = (ScrIndex)/(Everyleng);
            
            if (b != 0)
            {
                count1++;
            }
            
//            NSArray *GEtOnexArr = [self.xTitleArray subarrayWithRange:NSMakeRange(countS * count + count1,countS)];
//            NSArray *GEtOneyArr = [self.yValueArray subarrayWithRange:NSMakeRange(countS * count + count1,countS)];
            
            
            for (UIView *Views in [_scrollView subviews])
            {
                [Views removeFromSuperview];
            }
            
           // self.xAxisView = [[XAxisView alloc] initWithFrame:CGRectMake(0, 0, self.xTitleArray.count * self.pointGap + lastSpace, self.frame.size.height) xTitleArray:GEtOnexArr yValueArray:GEtOneyArr yMax:self.yMax yMin:self.yMin unit:self.unit];
            
                [_scrollView addSubview:self.xAxisView];
            
            //  _scrollView.contentSize = self.xAxisView.frame.size;
        }
    }
    else
    {
        Everyleng = (int)(TotalLength / self.xTitleArray.count);
        
        NSLog(@"每个数的长度:%d",Everyleng);
        
        int countS = (int)(ScreenWidth / Everyleng);
        
        NSLog(@"个数啦啦啦:%d",countS);
        
        if (ScrIndex > Everyleng)
        {
            int b = (ScrIndex)%(Everyleng);
            
            int count1 = (ScrIndex)/(Everyleng);
            
            if (b != 0)
            {
                count1++;
            }
            
//            NSArray *GEtOnexArr = [self.xTitleArray subarrayWithRange:NSMakeRange(count1,countS)];
//            NSArray *GEtOneyArr = [self.yValueArray subarrayWithRange:NSMakeRange(count1,countS)];
            
            for (UIView *Views in [_scrollView subviews])
            {
                [Views removeFromSuperview];
            }
            
           // self.xAxisView = [[XAxisView alloc] initWithFrame:CGRectMake(0, 0, self.xTitleArray.count * self.pointGap + lastSpace, self.frame.size.height) xTitleArray:GEtOnexArr yValueArray:GEtOneyArr yMax:self.yMax yMin:self.yMin unit:self.unit];
            
            [_scrollView addSubview:self.xAxisView];
            
          // _scrollView.contentSize = self.xAxisView.frame.size;
        }
    }
}

// 捏合手势监听方法
- (void)pinchGesture:(UIPinchGestureRecognizer *)recognizer
{
    if (recognizer.state == 3) {
        
        if (self.xAxisView.frame.size.width-lastSpace <= self.scrollView.frame.size.width) { //当缩小到小于屏幕宽时，松开回复屏幕宽度
            
            CGFloat scale = self.scrollView.frame.size.width / (self.xAxisView.frame.size.width-lastSpace);
            
            self.pointGap *= scale;
            
            [UIView animateWithDuration:0.25 animations:^{
                
                CGRect frame = self.xAxisView.frame;
                frame.size.width = self.scrollView.frame.size.width+lastSpace;
                self.xAxisView.frame = frame;
            }];
            
            self.xAxisView.pointGap = self.pointGap;
            
        }else if (self.xAxisView.frame.size.width-lastSpace >= self.xTitleArray.count * _defaultSpace){
            
            [UIView animateWithDuration:0.25 animations:^{
                CGRect frame = self.xAxisView.frame;
                frame.size.width = self.xTitleArray.count * self->_defaultSpace + lastSpace;
                self.xAxisView.frame = frame;
                
            }];
            
            self.pointGap = _defaultSpace;
            
            self.xAxisView.pointGap = self.pointGap;
        }
    }else{
        
        CGFloat currentIndex,leftMagin;
        if( recognizer.numberOfTouches == 2 ) {
            //2.获取捏合中心点 -> 捏合中心点距离scrollviewcontent左侧的距离
            CGPoint p1 = [recognizer locationOfTouch:0 inView:self.xAxisView];
            CGPoint p2 = [recognizer locationOfTouch:1 inView:self.xAxisView];
            CGFloat centerX = (p1.x+p2.x)/2;
            leftMagin = centerX - self.scrollView.contentOffset.x;

            currentIndex = centerX / self.pointGap;

            self.pointGap *= recognizer.scale;
            self.pointGap = self.pointGap > _defaultSpace ? _defaultSpace : self.pointGap;
            if (self.pointGap == _defaultSpace) {
                
                NSLog(@"已经放至最大");
            }
            self.xAxisView.pointGap = self.pointGap;
            recognizer.scale = 1.0;
            
            self.xAxisView.frame = CGRectMake(0, 0, self.xTitleArray.count * self.pointGap + lastSpace, self.frame.size.height);
            
            self.scrollView.contentOffset = CGPointMake(currentIndex*self.pointGap-leftMagin, 0);
            
        }
    }
    
    self.scrollView.contentSize = CGSizeMake(self.xAxisView.frame.size.width, 0);
}


- (void)event_longPressAction:(UILongPressGestureRecognizer *)longPress {
    
    if(UIGestureRecognizerStateChanged == longPress.state || UIGestureRecognizerStateBegan == longPress.state) {
        
        CGPoint location = [longPress locationInView:self.xAxisView];
        
        //相对于屏幕的位置
        CGPoint screenLoc = CGPointMake(location.x - self.scrollView.contentOffset.x , location.y);
        [self.xAxisView setScreenLoc:screenLoc];
        
        if (ABS(location.x - _moveDistance) > self.pointGap) { //不能长按移动一点点就重新绘图  要让定位的点改变了再重新绘图
            
            [self.xAxisView setIsShowLabel:YES];
            [self.xAxisView setIsLongPress:YES];
            self.xAxisView.currentLoc = location;
            _moveDistance = location.x;
        }
    }
    
    if(longPress.state == UIGestureRecognizerStateEnded)
    {
        _moveDistance = 0;
        //恢复scrollView的滑动
        [self.xAxisView setIsLongPress:NO];
        [self.xAxisView setIsShowLabel:NO];
    }
}

@end
