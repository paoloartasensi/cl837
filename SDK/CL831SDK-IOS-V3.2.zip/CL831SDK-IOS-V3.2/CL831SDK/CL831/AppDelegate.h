//
//  AppDelegate.h
//  CL831
//
//  Created by 郭志奇 on 2019/9/10.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

