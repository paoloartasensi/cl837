//
//  HeartChildViewController.h
//  CL831
//
//  Created by 郭志奇 on 2019/9/18.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol WriteParaDelegate <NSObject>

- (void)WriteHRStr:(NSString *)Str;
- (void)WriteRRStr:(NSString *)Str;
@end

@interface HeartChildViewController : UIViewController
{
    UIBarButtonItem *RightButton;
}

@property (nonatomic, assign)id<WriteParaDelegate>_WriteParaDelegate;

@property (weak, nonatomic) IBOutlet UIView *ChartBackView;

@property (weak, nonatomic) IBOutlet UIView *ListUTCView;

@property (weak, nonatomic) IBOutlet UICollectionView *UTCCollectionView;

@property (nonatomic, copy)NSString *ChooseState;

@property (weak, nonatomic) IBOutlet UILabel *HeadTitleLabel;

@property (weak, nonatomic) IBOutlet UILabel *ShowLabel;

@property (weak, nonatomic) IBOutlet UILabel *HRVLabel;

@property (weak, nonatomic) IBOutlet UILabel *HRVHeadLabel;

@end

NS_ASSUME_NONNULL_END
