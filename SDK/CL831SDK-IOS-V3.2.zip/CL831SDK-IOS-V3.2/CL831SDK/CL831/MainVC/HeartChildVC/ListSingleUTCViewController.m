//
//  ListSingleUTCViewController.m
//  CL831
//
//  Created by 郭志奇 on 2019/12/30.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import "ListSingleUTCViewController.h"
#import "ListSingleUTCTableViewCell.h"
#import "HeartBLEDevice.h"

@interface ListSingleUTCViewController ()<UITableViewDelegate,UITableViewDataSource,BLEDeviceDelegate>

@property (nonatomic,strong) NSMutableArray *DateArray;

@end

@implementation ListSingleUTCViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.DateArray = [[NSMutableArray alloc]init];
    //UI
    [self CreateUI];
}
#pragma mark - UI
- (void)CreateUI
{
    self.ListSingleTableView.delegate = self;
    self.ListSingleTableView.dataSource = self;
    self.ListSingleTableView.backgroundColor = [UIColor whiteColor];
    self.ListSingleTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;

}

#pragma mark - TableView Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 44;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.DateArray.count;
}

#pragma mark - UITableViewCell的显示
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //show
    static NSString *CellIdentifier = @"ListSingleUTCTableViewCell";
    ListSingleUTCTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell)
    {
        [tableView registerNib:[UINib nibWithNibName:@"ListSingleUTCTableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor=[UIColor clearColor];
    
    cell.UTCLabel.text = self.DateArray[indexPath.row];
    
    return cell;
}
#pragma mark - BLE代理方法
- (void)SDKGetSingleUTCArr:(NSMutableArray *_Nullable)UTCArr
{
    NSLog(@"UTCArr:%@",UTCArr);
    self.DateArray = [NSMutableArray arrayWithArray:UTCArr];
    [self.ListSingleTableView reloadData];
}

- (void)SDKBag1CountStr:(NSString *_Nullable)CountStr
{
    self.BagLabel.text = CountStr;
}

@end
