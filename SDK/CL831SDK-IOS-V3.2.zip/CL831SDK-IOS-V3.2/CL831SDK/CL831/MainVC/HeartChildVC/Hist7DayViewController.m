//
//  Hist7DayViewController.m
//  CL831
//
//  Created by 郭志奇 on 2019/9/18.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import "Hist7DayViewController.h"
#import "His7dayTableViewCell.h"
#import "HeartBLEDevice.h"
@interface Hist7DayViewController ()<UITableViewDelegate,UITableViewDataSource,BLEDeviceDelegate>

@property (nonatomic,strong) NSMutableArray *DateArray;

@property (nonatomic, strong)HeartBLEDevice *BLEdeivce;

@end

@implementation Hist7DayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.DateArray = [[NSMutableArray alloc]init];
    //UI
    [self CreateUI];
}
#pragma mark - UI
- (void)CreateUI
{
    self.HIS7DaySTableView.delegate = self;
    self.HIS7DaySTableView.dataSource = self;
    self.HIS7DaySTableView.backgroundColor = [UIColor whiteColor];
    self.HIS7DaySTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}

#pragma mark - TableView Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 127;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.DateArray.count;
}

#pragma mark - UITableViewCell的显示
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //show
    static NSString *CellIdentifier = @"His7dayTableViewCell";
    His7dayTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell)
    {
        [tableView registerNib:[UINib nibWithNibName:@"His7dayTableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor=[UIColor clearColor];
    
    NSMutableArray *arraA = self.DateArray[indexPath.row];
    
    cell.UTCLabel.text = arraA[0];
    cell.StepLabel.text = arraA[1];
    
    NSString *CalorStr = arraA[2];
    float b = [CalorStr floatValue]/10;
    
    cell.CalorLabel.text = [NSString stringWithFormat:@"%.1f",b];
    
    return cell;
}

#pragma mark - BLE代理方法
- (void)SDKGet7DaysHisParam:(NSMutableArray *_Nullable)ParamArr
{
    NSLog(@"ParamArr:%@",ParamArr);
    self.DateArray = [NSMutableArray arrayWithArray:ParamArr];
    [self.HIS7DaySTableView reloadData];
}

@end
