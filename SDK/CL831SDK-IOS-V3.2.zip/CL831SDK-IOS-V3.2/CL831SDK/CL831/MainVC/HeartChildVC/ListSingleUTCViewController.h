//
//  ListSingleUTCViewController.h
//  CL831
//
//  Created by 郭志奇 on 2019/12/30.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ListSingleUTCViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *ListSingleTableView;

@property (weak, nonatomic) IBOutlet UILabel *BagLabel;


@end

NS_ASSUME_NONNULL_END
