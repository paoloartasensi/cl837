//
//  ListTimeStepViewController.m
//  CL831
//
//  Created by 郭志奇 on 2019/12/30.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import "ListTimeStepViewController.h"
#import "ListTimeStepTableViewCell.h"
#import "HeartBLEDevice.h"
@interface ListTimeStepViewController ()<UITableViewDelegate,UITableViewDataSource,BLEDeviceDelegate>

@property (nonatomic,strong) NSMutableArray *DateArray;

@end

@implementation ListTimeStepViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.DateArray = [[NSMutableArray alloc]init];
    
    [self CreateUI];
}
#pragma mark - UI
- (void)CreateUI
{
    self.ListTimeStepTableView.delegate = self;
    self.ListTimeStepTableView.dataSource = self;
    self.ListTimeStepTableView.backgroundColor = [UIColor whiteColor];
    self.ListTimeStepTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
}

#pragma mark - TableView Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.DateArray.count;
}

#pragma mark - UITableViewCell的显示
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //show
    static NSString *CellIdentifier = @"ListTimeStepTableViewCell";
    ListTimeStepTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell)
    {
        [tableView registerNib:[UINib nibWithNibName:@"ListTimeStepTableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor=[UIColor clearColor];
    
    NSMutableArray *arraA = self.DateArray[indexPath.row];
    
    cell.UTCLabel.text = arraA[0];
    cell.StepLabel.text = arraA[1];
    
    return cell;
}

#pragma mark - BLE代理方法
- (void)SDKGetIntertTimeArr:(NSMutableArray *_Nullable)ParaArr
{
    NSLog(@"ParaArr:%@",ParaArr);
    self.DateArray = [NSMutableArray arrayWithArray:ParaArr];
    [self.ListTimeStepTableView reloadData];
}
- (void)SDKBagCountStr:(NSString *_Nullable)CountStr
{
    self.BagLabel.text = CountStr;
}

@end
