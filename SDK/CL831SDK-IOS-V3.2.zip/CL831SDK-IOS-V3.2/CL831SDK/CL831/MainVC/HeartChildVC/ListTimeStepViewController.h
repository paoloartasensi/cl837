//
//  ListTimeStepViewController.h
//  CL831
//
//  Created by 郭志奇 on 2019/12/30.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ListTimeStepViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *BagLabel;
@property (weak, nonatomic) IBOutlet UITableView *ListTimeStepTableView;
@end

NS_ASSUME_NONNULL_END
