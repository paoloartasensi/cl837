//
//  SleepDataTableViewCell.h
//  CL831
//
//  Created by 郭志奇 on 2019/11/11.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SleepDataTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *StartTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *EndTimeLabel;
@property (weak, nonatomic) IBOutlet UILabel *SorHLabel;
@property (weak, nonatomic) IBOutlet UILabel *SorMLabel;
@property (weak, nonatomic) IBOutlet UILabel *LigHLabel;
@property (weak, nonatomic) IBOutlet UILabel *LigMlabel;
@property (weak, nonatomic) IBOutlet UILabel *DepHLabel;
@property (weak, nonatomic) IBOutlet UILabel *DepMLabel;


@end

NS_ASSUME_NONNULL_END
