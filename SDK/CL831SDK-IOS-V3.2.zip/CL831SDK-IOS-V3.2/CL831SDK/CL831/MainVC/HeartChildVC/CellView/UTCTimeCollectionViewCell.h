//
//  UTCTimeCollectionViewCell.h
//  CL831
//
//  Created by 郭志奇 on 2019/9/19.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UTCTimeCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *UTCLabel;
@end

NS_ASSUME_NONNULL_END
