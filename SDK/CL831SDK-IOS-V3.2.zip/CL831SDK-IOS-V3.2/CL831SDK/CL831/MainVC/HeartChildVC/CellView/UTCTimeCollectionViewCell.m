//
//  UTCTimeCollectionViewCell.m
//  CL831
//
//  Created by 郭志奇 on 2019/9/19.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import "UTCTimeCollectionViewCell.h"

@implementation UTCTimeCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
