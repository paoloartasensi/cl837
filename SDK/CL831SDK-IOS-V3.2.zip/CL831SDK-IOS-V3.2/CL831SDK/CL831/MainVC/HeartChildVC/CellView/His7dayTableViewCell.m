//
//  His7dayTableViewCell.m
//  CL831
//
//  Created by 郭志奇 on 2019/9/19.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import "His7dayTableViewCell.h"

@implementation His7dayTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
