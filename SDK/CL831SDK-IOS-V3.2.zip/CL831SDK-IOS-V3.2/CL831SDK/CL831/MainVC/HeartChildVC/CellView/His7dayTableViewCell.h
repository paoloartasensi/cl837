//
//  His7dayTableViewCell.h
//  CL831
//
//  Created by 郭志奇 on 2019/9/19.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface His7dayTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *UTCLabel;
@property (weak, nonatomic) IBOutlet UILabel *StepLabel;
@property (weak, nonatomic) IBOutlet UILabel *CalorLabel;

@end

NS_ASSUME_NONNULL_END
