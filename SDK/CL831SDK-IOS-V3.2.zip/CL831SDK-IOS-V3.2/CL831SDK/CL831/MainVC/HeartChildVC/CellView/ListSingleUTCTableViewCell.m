//
//  ListSingleUTCTableViewCell.m
//  CL831
//
//  Created by 郭志奇 on 2019/12/30.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import "ListSingleUTCTableViewCell.h"

@implementation ListSingleUTCTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
