//
//  ListTimeStepTableViewCell.h
//  CL831
//
//  Created by 郭志奇 on 2019/12/30.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ListTimeStepTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *UTCLabel;

@property (weak, nonatomic) IBOutlet UILabel *StepLabel;

@end

NS_ASSUME_NONNULL_END
