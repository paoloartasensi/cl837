//
//  HeartChildViewController.m
//  CL831
//
//  Created by 郭志奇 on 2019/9/18.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import "HeartChildViewController.h"
#import "UTCTimeCollectionViewCell.h"
#import "GJLineChartView.h"
#import "EasyShowView.h"
#import "HeartBLEDevice.h"
#import "HeartBLEManager.h"

@interface HeartChildViewController ()<UICollectionViewDelegate,UICollectionViewDataSource,BLEDeviceDelegate,BLEManagerDelegate>
{
    int HRCount;
    int RRCount;
    HeartBLEManager *bleManager;
}

@property (nonatomic, strong)GJLineChartView *LineChartView;
@property (nonatomic, strong)NSMutableArray *UTCArr;

@property (nonatomic, strong)NSMutableArray *HRHISArr;
@property (nonatomic, strong)NSMutableArray *RRHISArr;
@property (nonatomic, strong)NSMutableArray *HRHISUTCArr;
@property (nonatomic, strong)NSMutableArray *HRHISUTCArr1;
@property (nonatomic, strong)NSMutableArray *RRHISUTCArr;

@property (nonatomic, strong)NSMutableArray *ParamArray;

@property (nonatomic, strong)NSMutableArray *nameArray;
@property (nonatomic, strong)HeartBLEDevice *BLEdeivce;

@end

@implementation HeartChildViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.UTCArr = [[NSMutableArray alloc]init];
    self.HRHISArr = [[NSMutableArray alloc]init];
    self.RRHISArr = [[NSMutableArray alloc]init];
    self.HRHISUTCArr = [[NSMutableArray alloc]init];
    self.HRHISUTCArr1 = [[NSMutableArray alloc]init];
    self.RRHISUTCArr = [[NSMutableArray alloc]init];
    self.ParamArray = [[NSMutableArray alloc]init];
    self.nameArray = [[NSMutableArray alloc]initWithObjects:@"Date",@"HR" ,nil];
    
    //UI
    [self CreateUI];
    [self btnRight];

    //消息通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(OverStrNofi:) name:@"OverGetParaStrNofication" object:nil];
}
#pragma mark - 刚进入界面走的方法
-(void)viewWillAppear:(BOOL)animated
{
   // self.UTCArr = [[NSMutableArray alloc]init];
}

#pragma mark - 导航栏右侧按钮
- (void)btnRight
{
    UIButton *BtnRight = [UIButton buttonWithType:UIButtonTypeCustom];
    BtnRight.frame = CGRectMake(0, 0, 60, 30);
    [BtnRight setTitle:@"保存文件" forState:UIControlStateNormal];
    [BtnRight addTarget:self action:@selector(rightButton) forControlEvents:UIControlEventTouchUpInside];
    RightButton = [[UIBarButtonItem alloc]initWithCustomView:BtnRight];
    [self.navigationItem setRightBarButtonItem:RightButton];
}

- (void)rightButton
{
    NSMutableArray *allarr = [[NSMutableArray alloc]init];
    
    for (int i = 0; i < _nameArray.count; i++)
    {
        NSMutableArray *arr = [NSMutableArray arrayWithArray:self.ParamArray[i]];
        
        [arr insertObject:_nameArray[i] atIndex:0];
        
        [allarr addObject:arr];
    }
    NSLog(@"AllArray:%@",allarr);
    
    NSMutableArray *mArray = [NSMutableArray array];
    NSInteger count = [allarr[0] count];
    
    for (NSInteger j = 0; j < count; j++) {
        for (NSInteger i = 0; i < allarr.count; i++) {
            [mArray addObject:allarr[i][j]];
        }
    }
    NSLog(@"mArray:%@",mArray);
    
    NSString *fileContent = [mArray componentsJoinedByString:@"\t"];
    NSLog(@"fileContent:%@",fileContent);
    // 字符串转换为可变字符串，方便改变某些字符
    NSMutableString *muStr = [fileContent mutableCopy];
    NSLog(@"muStr:%@",muStr);
    // 新建一个可变数组，存储每行最后一个\t的下标（以便改为\n）
    NSMutableArray *subMuArr = [NSMutableArray array];
    for (int i = 0; i < muStr.length; i ++) {
        NSRange range = [muStr rangeOfString:@"\t" options:NSBackwardsSearch range:NSMakeRange(i, 1)];
        if (range.length == 1) {
            [subMuArr addObject:@(range.location)];
        }
    }
    NSLog(@"调整之后的数组:%@",subMuArr);
    // 替换末尾\t
    for (NSUInteger i = 0; i < subMuArr.count; i ++) {
#pragma mark - 下面的6是列数，根据需求修改
        if ( i > 0 && (i%[allarr count] == 0) ) {
            [muStr replaceCharactersInRange:NSMakeRange([[subMuArr objectAtIndex:i-1] intValue], 1) withString:@"\n"];
        }
    }
    
    NSDate *date = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *strDate = [dateFormatter stringFromDate:date];
    NSLog(@"strDate:%@",strDate);
    
    NSString *path = [self finddocumentpath];//调用刚才的寻找Documents路径方法
    NSString *file = [NSString stringWithFormat:@"%@/%@.txt",path,strDate];
    NSLog(@"file:%@",file);
    NSError *error = Nil;
    BOOL result = [muStr writeToFile:file atomically:YES encoding:NSUTF8StringEncoding error:&error];
    
    if (result == YES)
    {
        NSLog(@"保存成功");
        [STTextHudTool showText:@"保存成功"];
    }
    else
    {
        NSLog(@"保存失败");
        [STTextHudTool showErrorText:@"保存失败"];
    }
}
#pragma mark - 寻找documents路径
- (NSString *)finddocumentpath{
    //寻找documents路径
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *value = paths.lastObject;
    NSLog(@"value--%@",value);
    return value;
}

#pragma mark - UI
- (void)CreateUI
{
    if (JFNav64 == 64)
    {
        self.ChartBackView.frame = CGRectMake(0, 70, self.ChartBackView.frame.size.width,210);
        self.HeadTitleLabel.frame = CGRectMake(7, 330, 140, 21);
        self.HRVHeadLabel.frame = CGRectMake(135, 330, 38, 21);
        self.HRVLabel.frame = CGRectMake(180, 330, 100, 21);
        self.ListUTCView.frame = CGRectMake(0, 360, self.ListUTCView.frame.size.width, 350);

    }
    else
    {
        self.ChartBackView.frame = CGRectMake(0, 110, self.ChartBackView.frame.size.width,220);
        self.HeadTitleLabel.frame = CGRectMake(7, 440, 140, 21);
        self.HRVHeadLabel.frame = CGRectMake(135, 440, 38, 21);
        self.HRVLabel.frame = CGRectMake(180, 440, 100, 21);
        self.ListUTCView.frame = CGRectMake(0, 470, self.ListUTCView.frame.size.width, 350);
    }
    
    self.LineChartView = [[GJLineChartView alloc]initWithFrame:self.ChartBackView.bounds];
    [self.ChartBackView addSubview:self.LineChartView];
    self.LineChartView.hidden = YES;
    
    self.UTCCollectionView.frame = self.ListUTCView.bounds;
    self.UTCCollectionView.delegate = self;
    self.UTCCollectionView.dataSource = self;
    self.UTCCollectionView.alwaysBounceVertical = YES;
    self.UTCCollectionView.backgroundColor = [UIColor whiteColor];
    self.UTCCollectionView.scrollEnabled = YES;
    
    [self.UTCCollectionView registerNib:[UINib nibWithNibName:@"UTCTimeCollectionViewCell" bundle:nil] forCellWithReuseIdentifier:@"cell1"];
}

#pragma mark - UICollectionViewDelegate代理方法
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(140, 40);
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(20, 32, 30, 53);
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.UTCArr.count;
}

#pragma mark - cell的显示
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UTCTimeCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell1" forIndexPath:indexPath];
    
    cell.layer.masksToBounds = YES;
    cell.layer.cornerRadius = 10.0;
    
    
    NSString *UTCStr = self.UTCArr[indexPath.row];
    NSString *UTCStrS = [NSString stringWithFormat:@"%lu",strtoul(UTCStr.UTF8String, 0, 16)];//十六进制转普通字符串
    
    NSString *DataUTC = [self transformTime:[UTCStrS intValue]];
    
    cell.UTCLabel.text = DataUTC;
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *UTCStr = self.UTCArr[indexPath.row];
    
    self.LineChartView.hidden = NO;
    
    if ([self.ChooseState isEqualToString:@"HR"])
    {
        NSString *StrLen = @"ff092201";
        NSString *StrLenS = [StrLen stringByAppendingString:UTCStr];

        [self._WriteParaDelegate WriteHRStr:StrLenS];
    }
    if ([self.ChooseState isEqualToString:@"RR"])
    {
        NSString *StrLen = @"ff092501";
        NSString *StrLenS = [StrLen stringByAppendingString:UTCStr];
        
        [self._WriteParaDelegate WriteRRStr:StrLenS];

    }
    [EasyLodingView showLodingText:@"Request data.." config:^EasyLodingConfig *{
        // static int a = 0 ;
        //int type = ++a%2 ? LodingShowTypeIndicatorLeft : LodingShowTypeIndicator;
        int type = LodingShowTypeIndicator;
        return [EasyLodingConfig shared].setLodingType(type);
    }];
}

#pragma mark - 清空本地缓存
- (void)clearAllUserDefaultsData
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *dic = [userDefaults dictionaryRepresentation];
    for (id  key in dic)
    {
        if ([key isEqual:@"HRYHIS"])
        {
            [userDefaults removeObjectForKey:key];
        }
    }
    [userDefaults synchronize];
}


#pragma mark - BLE代理方法
- (void)SDKGetHisHRUTCArr:(NSMutableArray *_Nullable)UTCArr
{
    self.UTCArr=(NSMutableArray *)[[UTCArr reverseObjectEnumerator] allObjects];
   // self.UTCArr = [NSMutableArray arrayWithArray:UTCArr];
    [self.UTCCollectionView reloadData];
}

- (void)SDKGetHisRRUTCArr:(NSMutableArray *_Nullable)UTCArr
{
    self.UTCArr=(NSMutableArray *)[[UTCArr reverseObjectEnumerator] allObjects];
   // self.UTCArr = [NSMutableArray arrayWithArray:UTCArr];
    [self.UTCCollectionView reloadData];
}

- (void)SDKGetHisHRParaArr:(NSMutableArray *_Nullable)UTCArr andHisHRArr:(NSMutableArray *_Nullable)HRArr
{
    NSArray *Xarrs = [UTCArr copy];
    NSArray *yarr = [HRArr copy];
    
    [self.HRHISUTCArr addObject:yarr];
    NSLog(@"self.HRHISUTCArr:%@",self.HRHISUTCArr);
    
    [self.LineChartView xTitleArray:Xarrs yValueArray:yarr yMax:280 yMin:0.0 unit:@"bmp"];
    
    [self.ParamArray addObject:Xarrs];
    [self.ParamArray addObject:yarr];
}

- (void)SDKGetHisRRParaArr:(NSMutableArray *_Nullable)UTCArr andHisRRArr:(NSMutableArray *_Nullable)HRArr
{
    NSArray *Xarrs = [UTCArr copy];
    NSArray *yarr = [HRArr copy];
    
    [self.LineChartView xTitleArray:Xarrs yValueArray:yarr yMax:1500 yMin:0.0 unit:@"bmp"];
}

#pragma mark - HRV值
- (void)SDKFitHRVHeartParamter:(NSString *_Nonnull)HeartStr
{
    NSLog(@"HeartStr:%@",HeartStr);
    self.HRVLabel.text = HeartStr;
}

#pragma mark - 通知事件
- (void)OverStrNofi:(NSNotification *)nofi
{
    NSDictionary *dict = [nofi userInfo];
    NSString *OverStr = [dict objectForKey:@"OverGetParaStr"];
    
    if ([OverStr isEqualToString:@"1"])
    {
         [EasyLodingView hidenLoding];
    }
}

#pragma mark - Conversion time
- (NSString *)transformTime:(long long)timestamp
{
    NSDate *date = [NSDate dateWithTimeIntervalSince1970:timestamp];
    NSString *template = @"yyyy-MM-dd HH:mm:ss";
    NSString *formatStr = [NSDateFormatter dateFormatFromTemplate:template options:0 locale:[NSLocale currentLocale]];
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:formatStr];
    [formatter setTimeZone:[NSTimeZone timeZoneWithName:@"UTC"]];
    NSString *time = [formatter stringFromDate:date];
    return time;
}

@end
