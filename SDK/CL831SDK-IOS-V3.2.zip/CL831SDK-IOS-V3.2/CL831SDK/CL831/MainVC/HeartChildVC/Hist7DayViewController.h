//
//  Hist7DayViewController.h
//  CL831
//
//  Created by 郭志奇 on 2019/9/18.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Hist7DayViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITableView *HIS7DaySTableView;


@end

NS_ASSUME_NONNULL_END
