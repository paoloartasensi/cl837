//
//  SearchTableViewCell.h
//  CL831
//
//  Created by 郭志奇 on 2019/9/10.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SearchTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *DeviceNameLabel;

@property (weak, nonatomic) IBOutlet UILabel *RSSILabel;

@end

NS_ASSUME_NONNULL_END
