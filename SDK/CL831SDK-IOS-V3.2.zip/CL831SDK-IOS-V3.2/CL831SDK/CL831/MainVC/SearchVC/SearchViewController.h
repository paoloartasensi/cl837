//
//  SearchViewController.h
//  CL831
//
//  Created by 郭志奇 on 2019/9/10.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SearchViewController : UIViewController
{
    UIBarButtonItem *rightView;
    int comeCount;
}

@property (weak, nonatomic) IBOutlet UITableView *SearchTableView;



@end

NS_ASSUME_NONNULL_END
