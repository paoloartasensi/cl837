//
//  SearchViewController.m
//  CL831
//
//  Created by 郭志奇 on 2019/9/10.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import "SearchViewController.h"
#import "SearchTableViewCell.h"
#import "HeartParamViewController.h"
#import "CDPDIYRefresh.h"
#import "HeartBLEDevice.h"
#import "HeartBLEManager.h"

@interface SearchViewController ()<BLEManagerDelegate,BLEDeviceDelegate,UITableViewDelegate,UITableViewDataSource>
{
    HeartBLEManager *bleManager;
}



@property (nonatomic,strong) NSMutableArray *AllDeviceArray;

//临时添加的小菊花动画
@property (nonatomic, strong) UIActivityIndicatorView * activityIndicator;//小菊花

@end

@implementation SearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationItem.title = @"Search Device";
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.AllDeviceArray = [[NSMutableArray alloc]init];
    
    //UI
    [self CreateUI];
    
    [self RightView];
    
    //消息通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(BLEParaArrayNofi:) name:@"BLEDeviceArrayNotification" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(stopDonghuaNofi:) name:@"StopDonghuaNofication" object:nil];//判断s连接状态
    
}

#pragma mark - 刚进入界面走的方法
- (void)viewWillDisappear:(BOOL)animated { // UIViewController对象的视图已经消失、被覆盖或是隐藏时调用；
    [super viewDidAppear:animated];

}

#pragma mark - UI
- (void)CreateUI
{
    self.SearchTableView.delegate = self;
    self.SearchTableView.dataSource = self;
    self.SearchTableView.backgroundColor = [UIColor whiteColor];
    self.SearchTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    //下拉列表视图
    __weak typeof(self) weakSelf = self;

    self.SearchTableView.mj_header=[CDPDIYRefresh getHeadRefreshWithRefreshBlock:^{
        [weakSelf headRefresh];
    }];
}

#pragma mark - 上下拉请求
//下拉
-(void)headRefresh
{
    __weak UITableView *tableView=self.SearchTableView;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(2*NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [tableView.mj_header endRefreshing];
        [self LoadSaomiaoData];
    });
}

#pragma mark - 加载周边设备
- (void)LoadSaomiaoData
{
    [self.AllDeviceArray removeAllObjects];
    [self.SearchTableView reloadData];

    NSString *SaoMiaoStr = @"1";
    NSDictionary *dict = [[NSDictionary alloc]initWithObjectsAndKeys:SaoMiaoStr,@"SaoMiaoStr", nil];
    NSNotification *notification =[NSNotification notificationWithName:@"StartSaoMiaoStrNotification" object:nil userInfo:dict];
    [[NSNotificationCenter defaultCenter] postNotification:notification];
}

#pragma mark - 导航栏右侧视图
- (void)RightView
{
    self.activityIndicator = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:(UIActivityIndicatorViewStyleGray)];
    self.activityIndicator.frame= CGRectMake(0, 0, 30, 30);
    self.activityIndicator.color = [UIColor whiteColor];
    //self.activityIndicator.hidesWhenStopped = NO;
    
    rightView = [[UIBarButtonItem alloc]initWithCustomView:self.activityIndicator];
    [self.navigationItem setRightBarButtonItem:rightView];
}

#pragma mark - TableView Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.AllDeviceArray.count;
}
#pragma mark - UITableViewCell的显示
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //show
    static NSString *CellIdentifier = @"SearchTableViewCell";
    SearchTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell)
    {
        [tableView registerNib:[UINib nibWithNibName:@"SearchTableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
        cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.backgroundColor=[UIColor clearColor];
    
    
    return cell;
}

#pragma mark - UITableViewcell的点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    [self.navigationController popViewControllerAnimated:YES];;
}
#pragma mark - 数据通知事件
-(void)BLEParaArrayNofi:(NSNotification *)Nofi//设备列表的通知事件
{
    NSDictionary *dict = [Nofi userInfo];
    NSMutableArray *DeviceArr = [dict objectForKey:@"BLEDeviceArrayNofi"];
    self.AllDeviceArray = DeviceArr;
    NSLog(@"传过来的数组:%@",DeviceArr);
    [self.SearchTableView reloadData];
}

- (void)stopDonghuaNofi:(NSNotification *)nofi//判断当前设备是否连接上
{
    NSDictionary *dict = [nofi userInfo];
    NSString *str = [dict objectForKey:@"StopDonghuaNofi"];
    comeCount++;
    if ([str isEqualToString:@"0"])
    {
        if (comeCount == 1)
        {
            [STTextHudTool showText:@"连接成功"];
            [self.activityIndicator stopAnimating];
        }
    }
}

#pragma mark - RSSI计算
- (float)calcDistByRSSI:(int)rssi
{
    int iRssi = abs(rssi);
    float power = (iRssi-59)/(10*2.0);
    return pow(10, power);
}
@end
