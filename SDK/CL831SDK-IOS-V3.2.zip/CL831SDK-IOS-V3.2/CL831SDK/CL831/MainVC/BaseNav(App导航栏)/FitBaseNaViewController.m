//
//  FitBaseNaViewController.m
//  Fitcare
//
//  Created by 郭志奇 on 2019/4/25.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import "FitBaseNaViewController.h"

@interface FitBaseNaViewController ()

@end

@implementation FitBaseNaViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //设置导航栏的字体和背景颜色 //79.79.79
    [self.navigationBar setBarTintColor:RGB(63, 160, 254)];
    [self.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor],NSForegroundColorAttributeName,nil]];
}

@end
