//
//  InfoTableViewCell.h
//  CL831
//
//  Created by 郭志奇 on 2020/4/1.
//  Copyright © 2020 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface InfoTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *SearchLabel;
@property (weak, nonatomic) IBOutlet UIButton *DISConnectLabel;
@property (weak, nonatomic) IBOutlet UIButton *GetUserInfoLabel;
@property (weak, nonatomic) IBOutlet UITextField *AgeText;
@property (weak, nonatomic) IBOutlet UITextField *HeightLabel;
@property (weak, nonatomic) IBOutlet UITextField *WeightLabel;
@property (weak, nonatomic) IBOutlet UITextField *PhoneNumText;
@property (weak, nonatomic) IBOutlet UISegmentedControl *SexSemel;
@property (weak, nonatomic) IBOutlet UIButton *SetUserBtn;

@property (weak, nonatomic) IBOutlet UIButton *Get7dayBtn;
@property (weak, nonatomic) IBOutlet UIButton *RestorBtn;
@property (weak, nonatomic) IBOutlet UIButton *GetHRhisBtn;
@property (weak, nonatomic) IBOutlet UIButton *GetNumStepBtn;
@property (weak, nonatomic) IBOutlet UIButton *GetHisSingBtn;
@property (weak, nonatomic) IBOutlet UISlider *rssiSlider;
@property (weak, nonatomic) IBOutlet UILabel *valueLabel;

@property (weak, nonatomic) IBOutlet UIButton *getWristTimeBtn;
@property (weak, nonatomic) IBOutlet UILabel *wristTimeLabel;
@property (weak, nonatomic) IBOutlet UITextField *setWristField;
@property (weak, nonatomic) IBOutlet UIButton *setWristTimeBtn;
@property (weak, nonatomic) IBOutlet UIButton *alertButton;

@end

NS_ASSUME_NONNULL_END
