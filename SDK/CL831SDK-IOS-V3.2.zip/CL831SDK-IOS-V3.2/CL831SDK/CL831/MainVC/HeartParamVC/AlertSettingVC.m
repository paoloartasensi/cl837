//
//  AlertSettingVC.m
//  CL831
//
//  Created by sylva on 2022/1/5.
//  Copyright © 2022 郭志奇. All rights reserved.
//

#import "AlertSettingVC.h"

@interface AlertSettingVC ()<BLEDeviceDelegate>

@end

@implementation AlertSettingVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.whiteColor;
    // Do any additional setup after loading the view from its nib.
}


-(void)viewWillAppear:(BOOL)animated
{
    [self.BLEdeivce setDelegate:self];
}

- (IBAction)getUTCAction:(id)sender {
    
    [self.BLEdeivce getUTCAndHeartAlertSwitch];
    
}
- (IBAction)switchAction:(id)sender {
    
    UISwitch *swi = (UISwitch *)sender;
    
    [self.BLEdeivce setHeartAlertSwitch: swi.isOn];

}

-(void)SDKGetUTC:(long)utc type:(int)alertType {
    
    NSDate *data = [NSDate dateWithTimeIntervalSince1970:utc];
    
    self.utcLabel.text = [NSString stringWithFormat:@"%@", data];
    
    if (alertType == 0) {
        self.alertTypeLabel.text = @"Alert by Age";
    } else if (alertType == 1) {
        self.alertTypeLabel.text = @"Alert by High-Low setting";
    } else {
        self.alertTypeLabel.text = @"--";
    }
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
