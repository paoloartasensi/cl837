//
//  TempAndOxygenViewController.m
//  CL831
//
//  Created by zhanghaoyan on 2023/10/23.
//  Copyright © 2023 郭志奇. All rights reserved.
//

#import "TempAndOxygenViewController.h"

@interface TempAndOxygenViewController ()<BLEDeviceDelegate>

@end

@implementation TempAndOxygenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated {
    [self.BLEdeivce setDelegate:self];
}


- (IBAction)getTemp:(id)sender {
    [self.BLEdeivce requestRealTimeTemperature];
}
- (IBAction)enterOxygenMode:(id)sender {
    [self.BLEdeivce enterOxygenMode];
}
- (IBAction)exitOxygenModel:(id)sender {
    [self.BLEdeivce quitOxygenMode];
    
    self.oxygenLabel.text = @"--";
}



-(void)SDKGetBloodOxygen:(int)BloodOxygen wristPosture:(BOOL)posture redPI:(int)PI onWrist:(BOOL)onWrist {
    
    NSString *post = posture ? @"姿势正确" : @"姿势错误";
    NSString *wrist = onWrist ? @"佩戴中" : @"脱腕";
    
    NSString *str = [NSString stringWithFormat:@"血氧:%d, %@, PI:%d, %@", BloodOxygen, post, PI, wrist];
    
    self.oxygenLabel.text = str;
    
}

-(void)SDKGetRealTimeTemp:(float)ambient wrist:(float)wrist body:(float)body {
    NSLog(@"ev=%f werist=%f body=%f", ambient, wrist, body);
    
    NSString *str = [NSString stringWithFormat:@"环境温度:%.1f, 手腕温度:%.1f, 身体温度:%.1f", ambient, wrist, body];
    
    self.tempLabel.text = str;
    
}


@end
