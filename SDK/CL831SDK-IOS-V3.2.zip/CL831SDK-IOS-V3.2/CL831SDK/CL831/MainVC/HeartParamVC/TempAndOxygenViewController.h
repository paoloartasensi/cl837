//
//  TempAndOxygenViewController.h
//  CL831
//
//  Created by zhanghaoyan on 2023/10/23.
//  Copyright © 2023 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeartBLEDevice.h"

NS_ASSUME_NONNULL_BEGIN

@interface TempAndOxygenViewController : UIViewController

@property (nonatomic, strong)HeartBLEDevice *BLEdeivce;

@property (weak, nonatomic) IBOutlet UILabel *tempLabel;
@property (weak, nonatomic) IBOutlet UILabel *oxygenLabel;

@end

NS_ASSUME_NONNULL_END
