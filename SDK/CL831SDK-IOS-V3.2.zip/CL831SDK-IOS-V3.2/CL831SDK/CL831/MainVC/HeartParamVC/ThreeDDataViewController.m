//
//  ThreeDDataViewController.m
//  CL831
//
//  Created by zhanghaoyan on 2023/10/23.
//  Copyright © 2023 郭志奇. All rights reserved.
//

#import "ThreeDDataViewController.h"
#import "MainViewController.h"

@interface ThreeDDataViewController ()<BLEDeviceDelegate>

@property (weak, nonatomic) IBOutlet UILabel *XLabel;
@property (weak, nonatomic) IBOutlet UILabel *YLabel;
@property (weak, nonatomic) IBOutlet UILabel *ZLabel;


@end

@implementation ThreeDDataViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.BLEdeivce setDelegate:self];
}


- (void)SDKGet3DData:(NSArray *)rawData {
   NSDictionary<NSString*, NSNumber *> *dic = rawData.firstObject;
   if (dic != nil) {
       self.XLabel.text = [dic[@"x"] stringValue];
       self.YLabel.text = [dic[@"y"] stringValue];
       self.ZLabel.text = [dic[@"z"] stringValue];
   }
}

-(void)SDKGetMaxHeartRate:(int)heartRate {
   self.maxHrLabel.text = [NSString stringWithFormat:@"%d", heartRate];
}

-(void)SDKGet3DFrequency:(int)frequency {
   self.frequencyLabel.text = [NSString stringWithFormat:@"%d", frequency];
}

- (void)SDKGet3DDataState:(BOOL)isOpen {
   [self.stateSwitch setOn:isOpen];
}


- (IBAction)setMaxHrAction:(id)sender {
   int hr = [self.maxHrTextField.text intValue];
   [self.BLEdeivce setMaxHeartRate:hr];
}
- (IBAction)getMaxHrAction:(id)sender {
   [self.BLEdeivce getMaxHeartRate];
}

- (IBAction)set3DFrequency:(UIButton *)sender {
   
   NSArray *arr = @[@(25), @(50), @(100), @(200), @(400)];
   UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Select Frequency" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
   for (NSNumber *fre in arr) {
       UIAlertAction *action = [UIAlertAction actionWithTitle:[fre stringValue] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
           [self.BLEdeivce set3DFrequency:[fre intValue]];
           [alert dismissViewControllerAnimated:true completion:nil];
           [sender setTitle:[NSString stringWithFormat:@"Frequency: %@", fre] forState:UIControlStateNormal];
       }];
       [alert addAction:action];
   }
   UIAlertAction *action = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
       [alert dismissViewControllerAnimated:true completion:nil];
   }];
   [alert addAction:action];
   [self presentViewController:alert animated:true completion:nil];
}

- (IBAction)get3DFrequency:(id)sender {
   [self.BLEdeivce get3DFrequency];
}
- (IBAction)switchChanged:(UISwitch *)sender {
   BOOL isOn = sender.isOn;
   [self.BLEdeivce openOrClose3DData:isOn];
}
- (IBAction)get3DState:(id)sender {
   
   [self.BLEdeivce get3DSwithState];
}

@end
