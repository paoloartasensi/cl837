//
//  HealthDataViewController.h
//  CL837
//
//  Created by zhanghaoyan on 2023/9/5.
//  Copyright © 2023 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeartBLEDevice.h"

NS_ASSUME_NONNULL_BEGIN

@interface HealthDataViewController : UIViewController

@property (nonatomic, strong)HeartBLEDevice *BLEdeivce;

@property (weak, nonatomic) IBOutlet UILabel *Vo2MaxLabel; // 最大摄氧量
@property (weak, nonatomic) IBOutlet UILabel *breathRateLabel; // 呼吸频率
@property (weak, nonatomic) IBOutlet UILabel *emotionLevelLabel; // 心情等级
@property (weak, nonatomic) IBOutlet UILabel *stressPercentLabel; // 压力百分率
@property (weak, nonatomic) IBOutlet UILabel *staminaLabel; // 疲劳等级

@end

NS_ASSUME_NONNULL_END
