//
//  UserInfoViewController.h
//  CL831
//
//  Created by sylva on 2022/1/17.
//  Copyright © 2022 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeartBLEDevice.h"

NS_ASSUME_NONNULL_BEGIN

@interface UserInfoViewController : UIViewController

@property (nonatomic, strong)HeartBLEDevice *BLEdeivce;

@property (weak, nonatomic) IBOutlet UITextField *AgeText;
@property (weak, nonatomic) IBOutlet UITextField *HeightLabel;
@property (weak, nonatomic) IBOutlet UITextField *WeightLabel;
@property (weak, nonatomic) IBOutlet UITextField *PhoneNumText;
@property (weak, nonatomic) IBOutlet UISegmentedControl *SexSemel;

@property (weak, nonatomic) IBOutlet UILabel *frequencyLabel;

@end

NS_ASSUME_NONNULL_END
