//
//  ThreeDDataViewController.h
//  CL831
//
//  Created by zhanghaoyan on 2023/10/23.
//  Copyright © 2023 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeartBLEDevice.h"

NS_ASSUME_NONNULL_BEGIN

@interface ThreeDDataViewController : UIViewController

@property (nonatomic, strong)HeartBLEDevice *BLEdeivce;

@property (weak, nonatomic) IBOutlet UISwitch *stateSwitch;

@property (weak, nonatomic) IBOutlet UILabel *frequencyLabel;
@property (weak, nonatomic) IBOutlet UITextField *maxHrTextField;
@property (weak, nonatomic) IBOutlet UILabel *maxHrLabel;

@end

NS_ASSUME_NONNULL_END
