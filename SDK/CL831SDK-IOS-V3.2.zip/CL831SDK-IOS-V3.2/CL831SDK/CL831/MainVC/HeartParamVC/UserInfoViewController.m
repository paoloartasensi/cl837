//
//  UserInfoViewController.m
//  CL831
//
//  Created by sylva on 2022/1/17.
//  Copyright © 2022 郭志奇. All rights reserved.
//

#import "UserInfoViewController.h"
#import "MainViewController.h"

@interface UserInfoViewController ()<BLEDeviceDelegate>
@property (weak, nonatomic) IBOutlet UILabel *XLabel;
@property (weak, nonatomic) IBOutlet UILabel *YLabel;
@property (weak, nonatomic) IBOutlet UILabel *ZLabel;
@property (weak, nonatomic) IBOutlet UITextField *maxHrTextField;
@property (weak, nonatomic) IBOutlet UILabel *maxHrLabel;
@property (weak, nonatomic) IBOutlet UISwitch *stateSwitch;

@end

@implementation UserInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.BLEdeivce setDelegate:self];
}

 #pragma mark - 获取/设置用户信息
 -(IBAction)getUserInfoBtnClick:(id)sender
 {
     NSString *UserStr = @"ff050300";
     [self.BLEdeivce BLEReadData:UserStr];
 }
 -(IBAction)SetUserInfoBtnClick:(id)sender
 {
     
     NSString *lenStr = @"ff0d04";
     
     NSString *oldStr = self.AgeText.text;
     NSString *SexStr =[NSString stringWithFormat:@"%ld",(long)self.SexSemel.selectedSegmentIndex];
     NSString *HeiStr = self.HeightLabel.text;
     NSString *WeiStr = self.WeightLabel.text;
     NSString *PhNumStr = self.PhoneNumText.text;
     
     NSString *oldStrs;NSString *SexStrs;NSString *HeiStrs;NSString *WeiStrs;
     
     if ([oldStr intValue] < 16)
     {
         NSString *Str = @"0";
         
         oldStrs = [Str stringByAppendingString:[MainViewController ToHex:[oldStr intValue]]];
     }
     else
     {
         oldStrs = [MainViewController ToHex:[oldStr intValue]];
     }
     
     if ([SexStr intValue] < 16)
     {
         NSString *Str = @"0";
         
         SexStrs = [Str stringByAppendingString:[MainViewController ToHex:[SexStr intValue]]];
     }
     else
     {
         SexStrs = [MainViewController ToHex:[SexStr intValue]];
     }
     if ([HeiStr intValue] < 16)
     {
         NSString *Str = @"0";
         
         HeiStrs = [Str stringByAppendingString:[MainViewController ToHex:[HeiStr intValue]]];
     }
     else
     {
         HeiStrs = [MainViewController ToHex:[HeiStr intValue]];
     }
     if ([WeiStr intValue] < 16)
     {
         NSString *Str = @"0";
         
         WeiStrs = [Str stringByAppendingString:[MainViewController ToHex:[WeiStr intValue]]];
     }
     else
     {
         WeiStrs = [MainViewController ToHex:[WeiStr intValue]];
     }
     
     long num = [PhNumStr longLongValue];
     
     Byte bytes[5] ={};
     
     NSMutableString *phoneNumStrs = [NSMutableString string];
     
     bytes[0] = (Byte)(num>>32);
     bytes[1] = (Byte)(num>>24);
     bytes[2] = (Byte)(num>>16);
     bytes[3] = (Byte)(num>>8);
     bytes[4] = (Byte)(num>>0);
     
     for (int i=0; i<5; i+=1) {
         
         NSString * phoneNumStr = [NSString stringWithFormat:@"%02x",bytes[i]];
         
         [phoneNumStrs appendString:phoneNumStr];
     }
     
     NSString *ALLStrs = [NSString stringWithFormat:@"%@%@%@%@%@%@",lenStr,oldStrs,SexStrs,WeiStrs,HeiStrs,phoneNumStrs];
     
     NSLog(@"ALLStrs:%@",ALLStrs);
     
     [self.BLEdeivce BLEReadData:ALLStrs];
 }
 

 #pragma mark - 用户信息
 - (void)SDKUserInfo:(NSString *_Nullable)OLdStr andSex:(NSString *_Nullable)SexStr andWeight:(NSString *_Nullable)WeightStr andHeight:(NSString *_Nullable)HeightStr andPhoneNum:(NSString *_Nullable)PhNumStr
 {
     
     self.AgeText.text = OLdStr;
     if ([SexStr isEqualToString:@"0"])
     {
         self.SexSemel.selectedSegmentIndex = 0;
     }
     else
     {
         self.SexSemel.selectedSegmentIndex = 1;
     }
     self.HeightLabel.text = HeightStr;
     self.WeightLabel.text = WeightStr;
     self.PhoneNumText.text = PhNumStr;
 }

 - (void)SDKGetUserInfoState:(NSString *_Nullable)StateStr
 {
     [STTextHudTool showText:@"Successfully set"];
 }

- (void)SDKGet3DData:(NSArray *)rawData {
    NSDictionary<NSString*, NSNumber *> *dic = rawData.firstObject;
    if (dic != nil) {
        self.XLabel.text = [dic[@"x"] stringValue];
        self.YLabel.text = [dic[@"y"] stringValue];
        self.ZLabel.text = [dic[@"z"] stringValue];
    }
}

-(void)SDKGetMaxHeartRate:(int)heartRate {
    self.maxHrLabel.text = [NSString stringWithFormat:@"%d", heartRate];
}

-(void)SDKGet3DFrequency:(int)frequency {
    self.frequencyLabel.text = [NSString stringWithFormat:@"%d", frequency];
}

- (void)SDKGet3DDataState:(BOOL)isOpen {
    [self.stateSwitch setOn:isOpen];
}

- (IBAction)setMaxHrAction:(id)sender {
    int hr = [self.maxHrTextField.text intValue];
    [self.BLEdeivce setMaxHeartRate:hr];
}
- (IBAction)getMaxHrAction:(id)sender {
    [self.BLEdeivce getMaxHeartRate];
}

- (IBAction)set3DFrequency:(UIButton *)sender {
    
    NSArray *arr = @[@(25), @(50), @(100), @(200), @(400)];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Select Frequency" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSNumber *fre in arr) {
        UIAlertAction *action = [UIAlertAction actionWithTitle:[fre stringValue] style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            [self.BLEdeivce set3DFrequency:[fre intValue]];
            [alert dismissViewControllerAnimated:true completion:nil];
            [sender setTitle:[NSString stringWithFormat:@"Frequency: %@", fre] forState:UIControlStateNormal];
        }];
        [alert addAction:action];
    }
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [alert dismissViewControllerAnimated:true completion:nil];
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:true completion:nil];
}

- (IBAction)get3DFrequency:(id)sender {
    [self.BLEdeivce get3DFrequency];
}
- (IBAction)switchChanged:(UISwitch *)sender {
    BOOL isOn = sender.isOn;
    [self.BLEdeivce openOrClose3DData:isOn];
}
- (IBAction)get3DState:(id)sender {
    
    [self.BLEdeivce get3DSwithState];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
