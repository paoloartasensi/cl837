//
//  SleepDataController.m
//  CL831
//
//  Created by sylva on 2022/10/28.
//  Copyright © 2022 郭志奇. All rights reserved.
//

#import "SleepDataController.h"

@interface SleepDataController ()<BLEDeviceDelegate>

@property (nonatomic, assign) int gapTime;
@property (nonatomic, assign) NSInteger lastTime;
@property (nonatomic, assign) NSInteger dayStartTime;

@property (nonatomic, assign) NSInteger dayLightSleep;
@property (nonatomic, assign) NSInteger dayOnceDeep;
@property (nonatomic, assign) NSInteger dayaWakeCount;
@property (nonatomic, assign) NSInteger dayDeepCount;
@property (nonatomic, assign) NSInteger dayTotal;

@property (nonatomic, strong) NSMutableArray *arr;
@property (nonatomic, strong) NSMutableArray *daySleep;


@end

@implementation SleepDataController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.arr = [NSMutableArray arrayWithCapacity:0];
    
    self.gapTime = 10800; //3个小时的间隔
    self.lastTime = 0;
    self.dayStartTime = 0;
    self.daySleep = [NSMutableArray arrayWithCapacity:0];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

-(void)viewWillAppear:(BOOL)animated
{
    self.lastTime = 0;
    [self.BLEdeivce setDelegate:self];
    
    [self.BLEdeivce getSleepData];
    
}

-(void)SDKGetSleepData:(NSArray *)sleepData {
    
    [self.arr removeAllObjects];
    
    for (int i = 0; i < sleepData.count; i++) {
        BOOL isLast = (i == sleepData.count - 1);
        NSDictionary *sleep = [self culSleepData:sleepData[i] isLast: isLast];
        [self.arr addObject:sleep];
    }
    //按天统计的结果加入末尾
    [self.arr addObjectsFromArray:self.daySleep];
    
    [self.tableView reloadData];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.arr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"cell"];
        cell.textLabel.numberOfLines = 0;
        [cell.textLabel sizeToFit];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:16];
    }
    
    NSString *content =  [self convertToJsonData:self.arr[indexPath.row]];
    cell.textLabel.text = content;
    NSInteger utc = [self.arr[indexPath.row][@"utcTime"] integerValue];
    cell.detailTextLabel.text = [self stampTransToTime:utc];
    
    NSNumber *total = self.arr[indexPath.row][@"total"];
    if (total == NULL) {
        cell.contentView.backgroundColor = RGB(206, 230, 253);
    } else {
        cell.contentView.backgroundColor = UIColor.whiteColor;
    }
    
    return cell;
}

//睡眠统计
- (NSDictionary *)culSleepData:(NSDictionary *)sleepData isLast:(BOOL)isLast {
    
    NSInteger lightSleep = 0;
    NSInteger onceDeep = 0;
    NSInteger awakeCount = 0;
    NSInteger deepCount = 0;
       
    NSArray *arr = sleepData[@"sleep"];
    NSString *total = [NSString stringWithFormat:@"%ld min", arr.count * 5];
    
    if (self.lastTime == 0) {
        self.lastTime = [sleepData[@"utcTime"] integerValue];
        self.dayStartTime = self.lastTime;
    } else if (self.lastTime > 0) {
        NSInteger current = [sleepData[@"utcTime"] integerValue];
        if (current - self.lastTime > self.gapTime) {
            
            if (_dayDeepCount < 3) { //小于三次算浅睡眠
                _dayLightSleep = _dayLightSleep + _dayDeepCount;
                _dayDeepCount = 0;
            } else {//连续三次或以上0为深睡
                _dayOnceDeep = _dayOnceDeep + _dayDeepCount;
                _dayDeepCount = 0;
            }
            
            NSDictionary *day = @{@"deepSleep":@(_dayOnceDeep * 5), @"lightSleep": @(_dayLightSleep * 5), @"awake": @(_dayaWakeCount * 5), @"utcTime": @(self.dayStartTime), @"dayTotal": @(_dayTotal)};
                        
            [self.daySleep addObject:day];
            
            self.dayOnceDeep = 0;
            self.dayDeepCount = 0;
            self.dayLightSleep = 0;
            self.dayaWakeCount = 0;
            self.dayTotal = 0;
            self.lastTime = [sleepData[@"utcTime"] integerValue];
            self.dayStartTime = self.lastTime;
        } else {
            self.lastTime = [sleepData[@"utcTime"] integerValue];
        }
    }
    
    self.dayTotal = self.dayTotal + arr.count * 5;
    
    for (int i = 0; i < arr.count; i++) {
        int sleep = [arr[i] intValue];
                
        if (sleep > 0) {
            if (deepCount < 3) { //小于三次算浅睡眠
                lightSleep = lightSleep + deepCount;
                deepCount = 0;
            } else {//连续三次或以上0为深睡
                onceDeep = onceDeep + deepCount;
                deepCount = 0;
            }
            if (sleep > 20) {
                awakeCount = awakeCount + 1;
            } else if (sleep > 0 && sleep <= 20) {
                lightSleep = lightSleep + 1;
            }
            
            // 小时连续计算 ，三小时后算新一组数据
            if (_dayDeepCount < 3) { //小时连续计算
                _dayLightSleep = _dayLightSleep + _dayDeepCount;
                _dayDeepCount = 0;
            } else {//连续三次或以上0为深睡
                _dayOnceDeep = _dayOnceDeep + _dayDeepCount;
                _dayDeepCount = 0;
            }
            
            if (sleep > 20) {
                _dayaWakeCount = _dayaWakeCount + 1;
            } else if (sleep > 0 && sleep <= 20) {
                _dayLightSleep = _dayLightSleep + 1;
            }
            
        } else {
            deepCount++;
            _dayDeepCount++;
            
            if (i == arr.count-1) {//最后一个数是0时
                if (deepCount < 3) { //小于三次算浅睡眠
                    lightSleep = lightSleep + deepCount;
                    deepCount = 0;
                } else {//连续三次或以上0为深睡
                    onceDeep = onceDeep + deepCount;
                    deepCount = 0;
                }
            }
        }
        
    }
    
    if (isLast) {
        if (_dayDeepCount < 3) {
            _dayLightSleep = _dayLightSleep + _dayDeepCount;
            _dayDeepCount = 0;
        } else {//连续三次或以上0为深睡
            _dayOnceDeep = _dayOnceDeep + _dayDeepCount;
            _dayDeepCount = 0;
        }
        
        NSDictionary *day = @{@"deepSleep":@(_dayOnceDeep * 5), @"lightSleep": @(_dayLightSleep * 5), @"awake": @(_dayaWakeCount * 5), @"utcTime": @(self.dayStartTime), @"dayTotal": @(_dayTotal)};
                    
        [self.daySleep addObject:day];
        
        self.dayOnceDeep = 0;
        self.dayDeepCount = 0;
        self.dayLightSleep = 0;
        self.dayaWakeCount = 0;
        self.dayTotal = 0;
        self.lastTime = [sleepData[@"utcTime"] integerValue];
        self.dayStartTime = self.lastTime;
    }
    
    return @{@"deepSleep":@(onceDeep * 5), @"lightSleep": @(lightSleep * 5), @"awake": @(awakeCount * 5), @"utcTime": sleepData[@"utcTime"], @"total": total};
    
}

- (NSString *)convertToJsonData:(NSDictionary *) dict {
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                        options:NSJSONWritingFragmentsAllowed
                                        error:&error];
    NSString *jsonString;
    if (!jsonData) {
        NSLog(@"%@",error);
    } else {
        jsonString = [[NSString alloc]initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    return jsonString;
}

- (NSString *)stampTransToTime:(NSInteger)stamp
{
    
    NSInteger timeZoneSecond = [[NSTimeZone localTimeZone] secondsFromGMT];
    NSDate *detaildate=[NSDate dateWithTimeIntervalSince1970:stamp - timeZoneSecond];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setTimeZone:[NSTimeZone localTimeZone]];//设置本地时区
    [dateFormatter setDateFormat:@"yyyy-MM-dd hh:mm:ss"];
    NSString *currentDateStr = [dateFormatter stringFromDate: detaildate];
    return currentDateStr;
}

/*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:<#@"reuseIdentifier"#> forIndexPath:indexPath];
    
    // Configure the cell...
    
    return cell;
}
*/

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
