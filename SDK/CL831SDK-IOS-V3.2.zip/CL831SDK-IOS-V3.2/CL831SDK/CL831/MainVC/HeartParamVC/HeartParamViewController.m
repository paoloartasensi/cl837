//
//  HeartParamViewController.m
//  CL831
//
//  Created by 郭志奇 on 2019/9/10.
//  Copyright © 2019 郭志奇. All rights reserved.
//

#import "HeartParamViewController.h"
#import "Hist7DayViewController.h"
#import "HeartChildViewController.h"
#import "SearchViewController.h"
#import "HeartBLEDevice.h"
#import "HeartBLEManager.h"
#import "SearchTableViewCell.h"
#import "ListTimeStepViewController.h"
#import "ListSingleUTCViewController.h"
#import "InfoTableViewCell.h"
#import "LYSDatePickerController.h"
#import "AlertSettingVC.h"
#import "MainViewController.h"


@interface HeartParamViewController ()<BLEManagerDelegate,UITableViewDataSource,UITableViewDelegate,WriteParaDelegate,LYSDatePickerSelectDelegate>
{
    HeartBLEManager *bleManager;
}

@property (nonatomic,strong)NSArray *ListPeripheral;

@property (nonatomic, strong)NSMutableArray *ParaSunArr;

@property (nonatomic, assign) int RSSI;

@end

@implementation HeartParamViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    bleManager = [HeartBLEManager sharedInstance];
//    [bleManager setDelegate:self];
    
    self.navigationItem.title = @"Heart Rate";
    self.view.backgroundColor = [UIColor whiteColor];
    
    //UI
    [self CreatUI];
    
    self.ListPeripheral = [NSArray array];
    self.ParaSunArr = [NSMutableArray array];
    
    self.RSSI = -100;
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [bleManager setDelegate:self];
    
    [self DisConnect:nil];
    
//    [self performSelector:@selector(DeviceSearch:) withObject:nil afterDelay:1];
}

- (void)CreatUI
{
    self.HeadTableView.delegate = self;
    self.HeadTableView.dataSource = self;
    self.HeadTableView.tag = 100;
    self.HeadTableView.backgroundColor = [UIColor clearColor];
    [self.HeadTableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
    self.HeadTableView.rowHeight = 50;
}

#pragma mark - Deivce Search
- (void)DeviceSearch:(id)sender
{
    if (!bleManager.isBLEPoweredOn)
    {
        NSLog(@"Your bluetooth is not on!");
        [STTextHudTool showText:@"Your bluetooth is not on!"];
        return;
    }
    
    //Set the agent
    [bleManager setDelegate:self];
    
    //Start scanning Settings for filtering
    [bleManager StartScanDevice];
    
    NSLog(@"Scanning equipment");
}

- (void)DisConnect:(id)sender
{
    [bleManager closeAllDevice];
}

#pragma mark - BLEManager Delegate
- (void)onDeviceFound:(NSArray *)deviceArray
{
//    NSLog(@"deviceArray:%@",deviceArray);
    NSMutableArray *arr = [NSMutableArray array];
    
    for (int i = 0; i < deviceArray.count; i++ ) {
        
        HeartBLEDevice * dev = deviceArray[i];
        
        int rssi = [dev.RSSI intValue];
        
        if (rssi > self.RSSI) {
            [arr addObject:dev];
        }
    }
    
    self.ListPeripheral = [NSArray arrayWithArray:arr];
    
    [self.HeadTableView reloadData];
}

- (void)bluetoothPowerOn:(BOOL)powerOn {
    if (powerOn) {
        NSLog(@"Scanning equipment");
        [bleManager StartScanDevice];
    }
}

#pragma mark - Judging the connection status
- (void)isConnected:(BOOL)isConnected withDevice:(HeartBLEDevice *)device
{
    if (isConnected)
    {
        [STTextHudTool showText:@"Connect Successful"];
    }
    else
    {
        [STTextHudTool showText:@"Connect Fail"];
    }
}

#pragma mark - Device disconnected
-(void)disconnected:(HeartBLEDevice *)device
{
    [STTextHudTool showText:@"DISConnect"];
}


- (void)SDKGetUserInfoState:(NSString *_Nullable)StateStr
{
    [STTextHudTool showText:@"Successfully set"];
}

#pragma mark - tableView dataSource &&  Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.ListPeripheral.count;
}
//show
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
        static NSString *CellIdentifier = @"SearchTableViewCell";
        SearchTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (!cell)
        {
            [tableView registerNib:[UINib nibWithNibName:@"SearchTableViewCell" bundle:nil] forCellReuseIdentifier:CellIdentifier];
            cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor=[UIColor clearColor];
        
        HeartBLEDevice *Device = self.ListPeripheral[indexPath.row];
        
        cell.DeviceNameLabel.text = Device.DeviceName;
        cell.RSSILabel.text = Device.RSSI;
        
        return cell;
}

// Click events
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
  
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    HeartBLEDevice *BLEdeivce = [self.ListPeripheral objectAtIndex:indexPath.row];
    [STTextHudTool showText:@"Device connected....."];
    [BLEdeivce connect];
    
    MainViewController *main = [[MainViewController alloc] init];
    main.BLEdeivce = BLEdeivce;
    main.RSSI = self.RSSI;
    [self.navigationController pushViewController:main animated:true];
    
}

-(void)rssiRangeChange:(UISlider *)slider {
        
    self.RSSI = (int)slider.value;
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    
//    cell.valueLabel.text = [NSString stringWithFormat:@"%d", self.RSSI];
    
}
-(IBAction)rssiValueChanged:(id)sender {
    
    
    
}

@end
