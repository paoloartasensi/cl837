//
//  MainViewController.h
//  CL831
//
//  Created by sylva on 2022/1/13.
//  Copyright © 2022 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeartBLEDevice.h"
#import "HeartBLEManager.h"
#import "HeartBLEDriver.h"

NS_ASSUME_NONNULL_BEGIN

@interface MainViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *BanbenLabel;
@property (weak, nonatomic) IBOutlet UILabel *DianciLabel;
@property (weak, nonatomic) IBOutlet UILabel *RSSILabel;
@property (weak, nonatomic) IBOutlet UILabel *StepLabel;
@property (weak, nonatomic) IBOutlet UILabel *KMLabel;
@property (weak, nonatomic) IBOutlet UILabel *CalorLabel;
@property (weak, nonatomic) IBOutlet UILabel *HeartLabel;
@property (weak, nonatomic) IBOutlet UIView *ParaBackView;


@property (weak, nonatomic) IBOutlet UITextField *maxField;
@property (weak, nonatomic) IBOutlet UITextField *minField;

@property (weak, nonatomic) IBOutlet UILabel *utcLabel;
@property (weak, nonatomic) IBOutlet UILabel *alertTypeLabel;

@property (weak, nonatomic) IBOutlet UISwitch *alertSwitch;

@property (nonatomic, strong)HeartBLEDevice *BLEdeivce;
@property (nonatomic, assign) int RSSI;

+ (NSString *)getHexByDecimal:(NSDecimalNumber *)decimal;
+ (NSString *)ToHex:(long long int)tmpid;

@end

NS_ASSUME_NONNULL_END
