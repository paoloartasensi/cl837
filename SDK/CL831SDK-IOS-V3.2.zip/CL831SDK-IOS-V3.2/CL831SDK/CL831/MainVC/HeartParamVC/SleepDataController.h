//
//  SleepDataController.h
//  CL831
//
//  Created by sylva on 2022/10/28.
//  Copyright © 2022 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeartBLEDevice.h"

NS_ASSUME_NONNULL_BEGIN

@interface SleepDataController : UITableViewController

@property (nonatomic, strong)HeartBLEDevice *BLEdeivce;


@end

NS_ASSUME_NONNULL_END
