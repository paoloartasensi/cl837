//
//  MainViewController.m
//  CL831
//
//  Created by sylva on 2022/1/13.
//  Copyright © 2022 郭志奇. All rights reserved.
//

#import "MainViewController.h"
 #import "Hist7DayViewController.h"
 #import "HeartChildViewController.h"
 #import "SearchViewController.h"
 #import "HeartBLEDevice.h"
 #import "HeartBLEManager.h"
 #import "SearchTableViewCell.h"
 #import "ListTimeStepViewController.h"
 #import "ListSingleUTCViewController.h"
 #import "InfoTableViewCell.h"
 #import "LYSDatePickerController.h"
// #import "AlertSettingVC.h"
#import "UserInfoViewController.h"
#import "ZIPFoundation/ZIPFoundation-Swift.h"
#import "iOSDFULibrary/iOSDFULibrary-Swift.h"
#import "SleepDataController.h"
#import "HealthDataViewController.h"
#import "TempAndOxygenViewController.h"
#import "ThreeDDataViewController.h"
#import "CalculateStepUTCViewController.h"
#import "EasyShowView.h"

 @interface MainViewController ()<BLEManagerDelegate,BLEDeviceDelegate,WriteParaDelegate,LYSDatePickerSelectDelegate, DFUServiceDelegate, DFUProgressDelegate, LoggerDelegate,StepWriteParaDelegate, UIDocumentPickerDelegate>
 {
     HeartBLEManager *bleManager;
 }

 @property (nonatomic, strong)NSMutableArray *ParaSunArr;
@property (nonatomic, strong) NSURL *fileURL;
@property (nonatomic, strong) UIButton *fileBtn;
 @end

 @implementation MainViewController


 - (void)viewDidLoad {
     [super viewDidLoad];
     // Do any additional setup after loading the view from its nib.
     
     bleManager = [HeartBLEManager sharedInstance];
     //[bleManager setDelegate:self];
     
     self.navigationItem.title = @"Heart Rate";
     self.view.backgroundColor = [UIColor whiteColor];
    
   
     self.ParaSunArr = [NSMutableArray array];
     
     self.RSSI = -100;
     
     [self.alertSwitch addTarget:self action:@selector(HRAlert:) forControlEvents:UIControlEventValueChanged];
     
     UIBarButtonItem *barBtn = [[UIBarButtonItem alloc] initWithTitle:@"DFU升级" style:UIBarButtonItemStylePlain target:self action:@selector(DFUMode)];
     
//     UIBarButtonItem *fileBtn = [[UIBarButtonItem alloc] initWithTitle:@"选择文件" style:UIBarButtonItemStylePlain target:self action:@selector(selectFile)];
     self.fileBtn = [UIButton buttonWithType:UIButtonTypeSystem];
     [self.fileBtn setTitle:@"选择文件" forState:UIControlStateNormal];
     [self.fileBtn addTarget:self action:@selector(selectFile) forControlEvents:UIControlEventTouchUpInside];
     
     self.fileBtn.frame = CGRectMake(0, 0, 180+30, 30);
     
     // UIButton -> UIBarButtonItem
     UIBarButtonItem *fileBarButton = [[UIBarButtonItem alloc] initWithCustomView:self.fileBtn];
     
     self.navigationItem.rightBarButtonItems = @[barBtn, fileBarButton];
     
 }

- (void)selectFile {
    //创建文件选择器，文件数据类型.data
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initWithDocumentTypes:@[@"public.data"] inMode:UIDocumentPickerModeImport];
    picker.delegate = self;
    
    //弹出选择器
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentAtURL:(NSURL *)url {
    
    self.fileURL = url;
    
    [self.fileBtn setTitle:url.lastPathComponent forState:UIControlStateNormal];
    
    NSLog(@"选择的文件路径: %@", url.path);
    
    [controller dismissViewControllerAnimated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    [self documentPicker:controller didPickDocumentAtURL:urls.firstObject];
}

//You can compare the software version read with the software version of the upgrade file, and then upgrade if they are inconsistent.
- (void)DFUMode {
    
    if(!self.fileURL) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"无文件" message:@"请先选择文件，然后进行DFU升级" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:okAction];
        
        [self presentViewController:alert animated:YES completion:nil];
    } else {
        NSLog(@"选择了文件%@", self.fileURL.lastPathComponent);
    
    
    [self.BLEdeivce enterDFU];
    
    [[HeartBLEDriver sharedInstance] scanDeviceName:@"CL831U" callback:^(CBPeripheral * _Nonnull peripheral) {
        
        NSLog(@"=====%@", peripheral.name);
        // update file path
//        NSString *path = [[NSBundle mainBundle] pathForResource:@"CL831_V4.0.1r26_dfu" ofType:@"zip"];
//        
//        NSURL *url = [NSURL fileURLWithPath:path];
        NSURL *url = self.fileURL;
        
        [self updateFirmware:peripheral filePath:url];
        
        
    }];
        NSLog(@"返回上一页面");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [self.navigationController popViewControllerAnimated:true];
        });
    }
}

//MARK: -- update firmware
//https://github.com/NordicSemiconductor/IOS-DFU-Library
- (void)updateFirmware:(CBPeripheral *)peri filePath:(NSURL *)file {
    
    
    CBCentralManager * manager = [HeartBLEDriver sharedInstance].centralManager;
    
    DFUFirmware *selectedFirmware = [[DFUFirmware alloc]initWithUrlToZipFile:file];
    
    DFUServiceInitiator *initiator = [[DFUServiceInitiator alloc] initWithCentralManager:manager target: peri];
   [initiator withFirmware:selectedFirmware];
   
   initiator.forceDfu =  [[[NSUserDefaults standardUserDefaults] valueForKey:@"dfu_force_dfu"] boolValue];
   initiator.packetReceiptNotificationParameter = [[[NSUserDefaults standardUserDefaults] valueForKey:@"dfu_number_of_packets"] intValue];
   
    initiator.logger = self;
    initiator.delegate = self;
    initiator.progressDelegate = self;
    [initiator startWithTarget:peri];
    
}

//更新进度
- (void)dfuProgressDidChangeFor:(NSInteger)part outOf:(NSInteger)totalParts to:(NSInteger)progress currentSpeedBytesPerSecond:(double)currentSpeedBytesPerSecond avgSpeedBytesPerSecond:(double)avgSpeedBytesPerSecond
{
    
    NSLog(@"更新进度:%ld%% (%ld/%ld)", (long) progress, (long) part, (long) totalParts);

    //先隐藏之前添加的加载试图，避免频繁叠加
    [EasyLodingView hidenLoding];
    
    [EasyLodingView showLodingText:[NSString stringWithFormat:@"更新进度:%ld%%", (long) progress] config:^EasyLodingConfig *{
        return [EasyLodingConfig shared].setLodingType(LodingShowTypeIndicator);
    }];
    
    if (progress == 100) {
        [EasyLodingView hidenLoding];
    }
}

-(void)logWith:(enum LogLevel)level message:(NSString *)message
{

    NSLog(@"%logWith ld: %@", (long)level, message);
}

- (void)dfuStateDidChangeTo:(enum DFUState)state
{
    NSLog(@"DFUState state%ld",state);
   
    if (state == DFUStateConnecting)
    {
        NSLog(@"Connecting...");
    }
    else if (state == DFUStateStarting)
    {
        NSLog(@"Starting DFU...");
    }
    else if (state == DFUStateEnablingDfuMode)
    {
        NSLog(@"Enabling DFU Bootloader...");
    }
    else if (state == DFUStateUploading)
    {
        NSLog(@"Uploading...");
    }
    else if (state == DFUStateValidating)
    {
        NSLog(@"Validating...");
    }
    else if (state == DFUStateDisconnecting)
    {
        NSLog(@"Disconnecting...");
    }
    else if (state == DFUStateDisconnecting)
    {
        NSLog(@"Disconnecting...");
    }
    else if (state == DFUStateCompleted)
    {
        NSLog(@"升级完成");
        [STTextHudTool showText:@"升级完成"];
        
    }
    else if (state == DFUStateAborted)
    {
       
    }
    else
    {
       
    }
    

}
//升级error信息
- (void)dfuError:(enum DFUError)error didOccurWithMessage:(NSString * _Nonnull)message
{
    NSLog(@"报错原因:%ld - %@",(long)error,message);
}

- (IBAction)get_set_userinfo:(id)sender {
    UserInfoViewController *userInfoVC = [[UserInfoViewController alloc] init];
    userInfoVC.BLEdeivce = self.BLEdeivce;
    [self.navigationController pushViewController:userInfoVC animated:true];
}

 -(void)viewWillAppear:(BOOL)animated
 {
     [bleManager setDelegate:self];
     [self.BLEdeivce setDelegate:self];
 }


 - (IBAction)DisConnect:(id)sender
 {
     [bleManager closeAllDevice];
 }

 - (IBAction)SetUTCClick:(id)sender
 {
     LYSDatePickerController *datePicker = [[LYSDatePickerController alloc] init];
     datePicker.headerView.backgroundColor = [UIColor colorWithRed:84/255.0 green:150/255.0 blue:242/255.0 alpha:1];
     datePicker.indicatorHeight = 5;
     datePicker.delegate = self;
     datePicker.headerView.centerItem.textColor = [UIColor whiteColor];
     datePicker.headerView.leftItem.textColor = [UIColor whiteColor];
     datePicker.headerView.rightItem.textColor = [UIColor whiteColor];
     datePicker.pickHeaderHeight = 40;
     datePicker.pickType = LYSDatePickerTypeDayAndTime;
     datePicker.minuteLoop = YES;
     datePicker.headerView.showTimeLabel = NO;
     datePicker.weakDayType = LYSDatePickerWeakDayTypeUSDefault;
     datePicker.showWeakDay = YES;
     [datePicker setDidSelectDatePicker:^(NSDate *date) {
         NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
         [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm"];
         
         NSLog(@"date:%@",date);
         
         //NSString *currentDate = [dateFormat stringFromDate:date];
         
         NSTimeInterval ti = [date timeIntervalSince1970];
         NSString *timeStr = [NSString stringWithFormat:@"%f",ti];
         NSLog(@"timeStr:%@",timeStr);
         int time = [timeStr intValue] + 28800;
         NSLog(@"time:%d",time);
         NSString *Data16Str = [MainViewController ToHex:time];
         
         NSString *UTCStr = @"ff0808";
         NSString *UTCStr1 = [UTCStr stringByAppendingString:Data16Str];
         
         NSLog(@"设置UTC时间:%@",UTCStr1);
         
         [self.BLEdeivce BLEReadData:UTCStr1];
         //[self BLEReadData:UTCStr1];
     }];
     [datePicker showDatePickerWithController:self];
 }

 #pragma mark - Get 7 days of historical data
 - (IBAction)Get6DayHisClick:(id)sender
 {
     NSString *StrLen = @"ff0416";
     [self.BLEdeivce BLEReadData:StrLen];
     
     Hist7DayViewController *HisVC = [[Hist7DayViewController alloc]init];
     HisVC.title = @"History";
     [self.BLEdeivce setDelegate:HisVC];

     [self.navigationController pushViewController:HisVC animated:YES];
 }

 #pragma mark - HR heart rate history data list request
 - (IBAction)HeartHisDanClick:(id)sender
 {
     NSString *StrLen = @"ff052100";
     [self.BLEdeivce BLEReadData:StrLen];
     
     HeartChildViewController *ChildVC = [[HeartChildViewController alloc]init];
     ChildVC.title = @"HR";
     ChildVC.ChooseState = @"HR";
     ChildVC._WriteParaDelegate = self;
     [self.BLEdeivce setDelegate:ChildVC];
     [self.navigationController pushViewController:ChildVC animated:YES];
 }

 #pragma mark - Get the number of steps in the interval
 - (IBAction)GetTimeStepClick:(id)sender
 {
     NSString *StrLen = @"ff054000";
     [self.BLEdeivce BLEReadData:StrLen];
     
     ListTimeStepViewController *StepVC = [[ListTimeStepViewController alloc]init];
     StepVC.title = @"Historical data";
     [self.BLEdeivce setDelegate:StepVC];
     [self.navigationController pushViewController:StepVC animated:YES];
 }

 #pragma mark - Get historical data for a single key press
 - (IBAction)GetHisPressClick:(id)sender
 {
     NSString *StrLen = @"ff054200";
     [self.BLEdeivce BLEReadData:StrLen];
     
     ListSingleUTCViewController *UTCVC = [[ListSingleUTCViewController alloc]init];
     UTCVC.title = @"Historical data";
     [self.BLEdeivce setDelegate:UTCVC];
     [self.navigationController pushViewController:UTCVC animated:YES];
 }

 #pragma mark - restoration
 - (IBAction)RestClick:(id)sender
 {
     NSString *StrLen = @"ff05f300";
     [self.BLEdeivce BLEReadData:StrLen];
 }

#pragma  mark - Get Calculate Step UTC
- (IBAction)GetCalCulateStepUTC:(id)sender
{
    NSString *StrLen = @"ff059000";
    [self.BLEdeivce BLEReadData:StrLen];
    
    CalculateStepUTCViewController *vc = [[CalculateStepUTCViewController alloc] init];
    vc.StepChooseState = @"Step";
    vc._StepWriteParaDelegate = self;
    [self.BLEdeivce setDelegate:vc];
    [self.navigationController pushViewController:vc animated:YES];
}

 #pragma mark - Device disconnected
 -(void)disconnected:(HeartBLEDevice *)device
 {
     [STTextHudTool showText:@"DISConnect"];
     
     self.BanbenLabel.text = @"--";
     self.DianciLabel.text = @"--";
     self.RSSILabel.text = @"--";
     self.StepLabel.text = @"--";
     self.KMLabel.text = @"--";
     self.CalorLabel.text = @"--";
     self.HeartLabel.text = @"--";
     
    // [self.navigationController popViewControllerAnimated:true];
     
 }

#pragma mark - Judging the connection status
- (void)isConnected:(BOOL)isConnected withDevice:(HeartBLEDevice *)device
{
    if (isConnected)
    {
        [STTextHudTool showText:@"Connect Successful"];
        self.RSSILabel.text = device.RSSI;
    }
    else
    {
        [STTextHudTool showText:@"Connect Fail"];
    }
}


 #pragma mark - BLEDeviceDelegate
 - (void)SDKFitRunSParamter:(int)RunPara andFitKM:(float)FitKM andFitCalor:(float)FitCalor
 {
     self.StepLabel.text = [NSString stringWithFormat:@"%d",RunPara];
     self.KMLabel.text = [NSString stringWithFormat:@"%.1f",FitKM];
     self.CalorLabel.text = [NSString stringWithFormat:@"%.1f",FitCalor];
 }

 - (void)SDKFitHeartParamter:(NSString *_Nonnull)HeartStr
 {
//     NSLog(@"心率值打印:%@",HeartStr);
     self.HeartLabel.text = HeartStr;
 }

 - (void)SDKDianciStr:(NSString *_Nullable)DianStr
 {
     NSString *str1 = @"%";
     
     self.DianciLabel.text = [DianStr stringByAppendingString:str1];
 }

 - (void)SDKReadRSSI:(NSString *_Nullable)RSSIStr
 {
     self.RSSILabel.text = RSSIStr;
 }

 - (void)SDKDeviceBanBen:(NSString *_Nullable)BenStr
 {
     self.BanbenLabel.text = BenStr;
 }

 #pragma mark - Deleagte Back
 - (void)WriteHRStr:(NSString *)Str
 {
     [self.BLEdeivce BLEReadData:Str];
 }
 - (void)WriteRRStr:(NSString *)Str
 {
     [self.BLEdeivce BLEReadData:Str];
 }
- (void)WriteStepStr:(NSString *)Str
{
    [self.BLEdeivce BLEReadData:Str];
}
 + (NSString *)ToHex:(long long int)tmpid
 {
     NSString *nLetterValue;
     NSString *str =@"";
     long long int ttmpig;
     for (int i = 0; i<12; i++) {
         ttmpig=tmpid%16;
         tmpid=tmpid/16;
         switch (ttmpig)
         {
             case 10:
                 nLetterValue =@"A";break;
             case 11:
                 nLetterValue =@"B";break;
             case 12:
                 nLetterValue =@"C";break;
             case 13:
                 nLetterValue =@"D";break;
             case 14:
                 nLetterValue =@"E";break;
             case 15:
                 nLetterValue =@"F";break;
             default:nLetterValue=[[NSString alloc]initWithFormat:@"%lli",ttmpig];
                 
         }
         str = [nLetterValue stringByAppendingString:str];
         if (tmpid == 0) {
             break;
         }
     }
     return str;
 }
+ (NSString *)getHexByDecimal:(NSDecimalNumber *)decimal {
     
     //10进制转换16进制（支持无穷大数）
     NSString *hex =@"";
     NSString *letter;
     NSDecimalNumber *lastNumber = decimal;
     for (int i = 0; i<999; i++) {
         NSDecimalNumber *tempShang = [lastNumber decimalNumberByDividingBy:[NSDecimalNumber decimalNumberWithString:@"16"]];
         NSString *tempShangString = [tempShang stringValue];
         if ([tempShangString containsString:@"."]) {
             // 有小数
             tempShangString = [tempShangString substringToIndex:[tempShangString rangeOfString:@"."].location];
             //            DLog(@"%@", tempShangString);
             NSDecimalNumber *number = [[NSDecimalNumber decimalNumberWithString:tempShangString] decimalNumberByMultiplyingBy:[NSDecimalNumber decimalNumberWithString:@"16"]];
             NSDecimalNumber *yushu = [lastNumber decimalNumberBySubtracting:number];
             int yushuInt = [[yushu stringValue] intValue];
             switch (yushuInt) {
                 case 10:
                     letter =@"A"; break;
                 case 11:
                     letter =@"B"; break;
                 case 12:
                     letter =@"C"; break;
                 case 13:
                     letter =@"D"; break;
                 case 14:
                     letter =@"E"; break;
                 case 15:
                     letter =@"F"; break;
                 default:
                     letter = [NSString stringWithFormat:@"%d", yushuInt];
             }
             lastNumber = [NSDecimalNumber decimalNumberWithString:tempShangString];
         } else {
             // 没有小数
             if (tempShangString.length <= 2 && [tempShangString intValue] < 16) {
                 int num = [tempShangString intValue];
                 if (num == 0) {
                     break;
                 }
                 switch (num) {
                     case 10:
                         letter =@"A"; break;
                     case 11:
                         letter =@"B"; break;
                     case 12:
                         letter =@"C"; break;
                     case 13:
                         letter =@"D"; break;
                     case 14:
                         letter =@"E"; break;
                     case 15:
                         letter =@"F"; break;
                     default:
                         letter = [NSString stringWithFormat:@"%d", num];
                 }
                 hex = [letter stringByAppendingString:hex];
                 break;
             } else {
                 letter = @"0";
             }
             lastNumber = tempShang;
         }
         
         hex = [letter stringByAppendingString:hex];
     }
     //    return hex;
     return hex.length > 0 ? hex : @"0";
 }

-(void)SDKGetHRGoal:(int)goal max:(int)max min:(int)min {
   
    self.maxField.text = [NSString stringWithFormat:@"%d", max];
    self.minField.text = [NSString stringWithFormat:@"%d", min];
}
- (IBAction)SetUTCAndHRAlert:(id)sender {
    
    [self.BLEdeivce getUTCAndHeartAlertSwitch];
}

-(IBAction)setHRStatus:(id)sender {
    
    int max = [self.maxField.text intValue];
    int min = [self.minField.text intValue];
    
    [self.BLEdeivce setHRGoal:0 max:max min:min];
}

-(IBAction)getHRStatus:(id)sender {
    [self.BLEdeivce getHRGoalAndRange];
}
- (void)HRAlert:(UISwitch *)sender {
    
    [self.BLEdeivce setHeartAlertSwitch: sender.isOn];
}

-(void)SDKGetUTC:(long)utc type:(int)alertType {
    
    NSDate *data = [NSDate dateWithTimeIntervalSince1970:utc];
    
    self.utcLabel.text = [NSString stringWithFormat:@"%@", data];
    
    if (alertType == 1) {
        self.alertTypeLabel.text = @"Alert by Age";
        [self.alertSwitch setOn:true];
    } else if (alertType == 0) {
        self.alertTypeLabel.text = @"Alert by High-Low setting";
        [self.alertSwitch setOn:false];
    } else {
        self.alertTypeLabel.text = @"--";
    }
}
- (IBAction)getSleepData:(id)sender {
    
    SleepDataController *sp = [[SleepDataController alloc] init];
    sp.BLEdeivce = self.BLEdeivce;
    [self.navigationController pushViewController:sp animated:true];
    
}

#pragma mark - Health real-time data
-(IBAction)getHealthData:(id)sender {
    HealthDataViewController *hd = [[HealthDataViewController alloc] init];
    hd.BLEdeivce = self.BLEdeivce;
    [self.navigationController pushViewController:hd animated:true];
}

#pragma mark - Get blood oxygen and real-time temperature
-(IBAction)getTempOxygen:(id)sender {
    
    TempAndOxygenViewController * tem = [[TempAndOxygenViewController alloc] init];
    tem.BLEdeivce = self.BLEdeivce;
    [self.navigationController pushViewController:tem animated:true];
}

#pragma mark - 3D data and target heart rate
-(IBAction)getThreeDAndHeartRate:(id)sender {
    
    ThreeDDataViewController * dd = [[ThreeDDataViewController alloc] init];
    dd.BLEdeivce = self.BLEdeivce;
    [self.navigationController pushViewController:dd animated:true];
}
@end

 
