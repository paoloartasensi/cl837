//
//  HealthDataViewController.m
//  CL837
//
//  Created by zhanghaoyan on 2023/9/5.
//  Copyright © 2023 郭志奇. All rights reserved.
//

#import "HealthDataViewController.h"
#import "HeartBLEDevice.h"

@interface HealthDataViewController ()<BLEDeviceDelegate>

@property (nonatomic, assign) NSInteger Vo2Max;
@property (nonatomic, assign) NSInteger breathRate;
@property (nonatomic, assign) NSInteger emotionLevel;
@property (nonatomic, assign) NSInteger stressPercent;
@property (nonatomic, assign) NSInteger stamina;

@end

@implementation HealthDataViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:true];
    [self.BLEdeivce setDelegate:self];

}

- (void)SDKGetVo2Max:(int)Vo2Max breathRate:(int)breathRate emotionLevel:(int)emotionLevel stressPercent:(int)stressPercent stamina:(int)stamina {
    // Update the labels with new data
    self.Vo2MaxLabel.text = [NSString stringWithFormat:@" %d", Vo2Max];
    self.breathRateLabel.text = [NSString stringWithFormat:@" %d", breathRate];
    self.emotionLevelLabel.text = [NSString stringWithFormat:@" %d", emotionLevel];
    self.stressPercentLabel.text = [NSString stringWithFormat:@" %d%%", stressPercent];
    self.staminaLabel.text = [NSString stringWithFormat:@" %d", stamina];
    
}


@end
