//
//  InfoTableViewCell.m
//  CL831
//
//  Created by 郭志奇 on 2020/4/1.
//  Copyright © 2020 郭志奇. All rights reserved.
//

#import "InfoTableViewCell.h"

@implementation InfoTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
