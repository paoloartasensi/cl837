//
//  AlertSettingVC.h
//  CL831
//
//  Created by sylva on 2022/1/5.
//  Copyright © 2022 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeartBLEDevice.h"

NS_ASSUME_NONNULL_BEGIN

@interface AlertSettingVC : UIViewController

@property (nonatomic, strong)HeartBLEDevice *BLEdeivce;


@property (weak, nonatomic) IBOutlet UILabel *utcLabel;
@property (weak, nonatomic) IBOutlet UILabel *alertTypeLabel;

@end

NS_ASSUME_NONNULL_END
