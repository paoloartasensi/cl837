//
//  CalculateStepUTCViewController.h
//  CL831
//
//  Created by Chileaf.zhanghaoyan on 2024/8/10.
//  Copyright © 2024 郭志奇. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol StepWriteParaDelegate <NSObject>

- (void)WriteStepStr:(NSString *)Str;

@end

@interface CalculateStepUTCViewController : UIViewController
{
    UIBarButtonItem *RightButton;
}

@property (nonatomic, assign)id<StepWriteParaDelegate>_StepWriteParaDelegate;

@property (weak, nonatomic) IBOutlet UIView *StepChartBackView;

@property (weak, nonatomic) IBOutlet UIView *StepListUTCView;

@property (weak, nonatomic) IBOutlet UICollectionView *StepUTCCollectionView;

@property (nonatomic, copy)NSString *StepChooseState;

@property (weak, nonatomic) IBOutlet UILabel *StepHeadTitleLabel;

@property (weak, nonatomic) IBOutlet UILabel *StepShowLabel;

@property (weak, nonatomic) IBOutlet UILabel *StepHRVLabel;

@property (weak, nonatomic) IBOutlet UILabel *StepHRVHeadLabel;

@end

NS_ASSUME_NONNULL_END
