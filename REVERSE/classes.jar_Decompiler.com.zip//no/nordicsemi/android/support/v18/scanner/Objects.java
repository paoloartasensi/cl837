package no.nordicsemi.android.support.v18.scanner;

import java.util.Arrays;

class Objects {
   static boolean deepEquals(Object a, Object b) {
      if (a != null && b != null) {
         if (a instanceof Object[] && b instanceof Object[]) {
            return Arrays.deepEquals((Object[])a, (Object[])b);
         } else if (a instanceof boolean[] && b instanceof boolean[]) {
            return Arrays.equals((boolean[])a, (boolean[])b);
         } else if (a instanceof byte[] && b instanceof byte[]) {
            return Arrays.equals((byte[])a, (byte[])b);
         } else if (a instanceof char[] && b instanceof char[]) {
            return Arrays.equals((char[])a, (char[])b);
         } else if (a instanceof double[] && b instanceof double[]) {
            return Arrays.equals((double[])a, (double[])b);
         } else if (a instanceof float[] && b instanceof float[]) {
            return Arrays.equals((float[])a, (float[])b);
         } else if (a instanceof int[] && b instanceof int[]) {
            return Arrays.equals((int[])a, (int[])b);
         } else if (a instanceof long[] && b instanceof long[]) {
            return Arrays.equals((long[])a, (long[])b);
         } else {
            return a instanceof short[] && b instanceof short[] ? Arrays.equals((short[])a, (short[])b) : a.equals(b);
         }
      } else {
         return a == b;
      }
   }

   static boolean equals(Object a, Object b) {
      return a == null ? b == null : a.equals(b);
   }

   static int hash(Object... values) {
      return Arrays.hashCode(values);
   }

   static String toString(Object o) {
      return o == null ? "null" : o.toString();
   }
}
